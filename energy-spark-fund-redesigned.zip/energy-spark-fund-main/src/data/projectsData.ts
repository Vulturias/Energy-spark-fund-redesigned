// Demo crowdfunding projects data

export interface Project {
  id: string;
  title: string;
  description: string;
  shortDescription: string;
  category: "solar" | "wind" | "biogas" | "hydro" | "efficiency";
  location: string;
  fundingGoal: number;
  fundingRaised: number;
  backers: number;
  daysLeft: number;
  image: string;
  creator: {
    name: string;
    avatar: string;
    verified: boolean;
  };
  rewards: Reward[];
  updates: Update[];
  impact: {
    co2Saved: number; // tonnes per year
    homePowered: number;
    jobsCreated: number;
  };
  featured: boolean;
}

export interface Reward {
  id: string;
  title: string;
  minAmount: number;
  description: string;
  backers: number;
  estimatedDelivery: string;
}

export interface Update {
  id: string;
  title: string;
  content: string;
  date: string;
}

export const projects: Project[] = [
  {
    id: "solar-village-chisinau",
    title: "Solar Village Chișinău",
    shortDescription: "Community solar farm powering 500 homes in northern Chișinău",
    description: `Transform the energy future of Chișinău with Moldova's largest community solar project. Our 2MW solar farm will provide clean, affordable electricity to 500 households while creating local jobs and reducing carbon emissions.

**Why This Matters**
Moldova imports over 75% of its electricity, making energy security a critical concern. This project directly addresses this by generating local, renewable power.

**Project Details**
- 2MW solar installation
- Located on unused agricultural land
- Grid-connected with net metering
- 25-year operational lifespan

**Community Benefits**
- 20% electricity cost reduction for participants
- Local employment during construction
- Annual community energy fund`,
    category: "solar",
    location: "Chișinău, Moldova",
    fundingGoal: 850000,
    fundingRaised: 642500,
    backers: 1247,
    daysLeft: 23,
    image: "https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800",
    creator: {
      name: "EnerVerde Moldova",
      avatar: "https://api.dicebear.com/7.x/initials/svg?seed=EVM",
      verified: true,
    },
    rewards: [
      {
        id: "r1",
        title: "Community Supporter",
        minAmount: 50,
        description: "Recognition on project website + quarterly newsletter updates",
        backers: 456,
        estimatedDelivery: "March 2025",
      },
      {
        id: "r2",
        title: "Energy Pioneer",
        minAmount: 250,
        description: "5% discount on electricity for 2 years + exclusive tour of facility",
        backers: 234,
        estimatedDelivery: "June 2025",
      },
      {
        id: "r3",
        title: "Solar Champion",
        minAmount: 1000,
        description: "10% discount for 5 years + naming rights for 1 solar panel",
        backers: 89,
        estimatedDelivery: "June 2025",
      },
      {
        id: "r4",
        title: "Community Investor",
        minAmount: 5000,
        description: "Revenue share of 3% annually + VIP events + all previous rewards",
        backers: 23,
        estimatedDelivery: "December 2025",
      },
    ],
    updates: [
      {
        id: "u1",
        title: "Land permits approved!",
        content: "Great news! We received final approval for the project site.",
        date: "2024-12-15",
      },
      {
        id: "u2",
        title: "Equipment order placed",
        content: "Solar panels and inverters ordered from European suppliers.",
        date: "2024-12-01",
      },
    ],
    impact: {
      co2Saved: 1200,
      homePowered: 500,
      jobsCreated: 15,
    },
    featured: true,
  },
  {
    id: "wind-farm-balti",
    title: "Wind Power Bălți",
    shortDescription: "5 wind turbines generating clean energy for industrial zone",
    description: `Harness the power of Moldova's northern winds to power Bălți's growing industrial sector. This 10MW wind farm will reduce industrial energy costs while promoting sustainable manufacturing.

**Project Highlights**
- 5 modern wind turbines (2MW each)
- Strategic location with optimal wind conditions
- Direct power supply to industrial consumers
- Grid backup for residential areas`,
    category: "wind",
    location: "Bălți, Moldova",
    fundingGoal: 2500000,
    fundingRaised: 1875000,
    backers: 892,
    daysLeft: 45,
    image: "https://images.unsplash.com/photo-1532601224476-15c79f2f7a51?w=800",
    creator: {
      name: "WindTech Solutions",
      avatar: "https://api.dicebear.com/7.x/initials/svg?seed=WTS",
      verified: true,
    },
    rewards: [
      {
        id: "r1",
        title: "Wind Watcher",
        minAmount: 100,
        description: "Project updates + certificate of contribution",
        backers: 312,
        estimatedDelivery: "April 2025",
      },
      {
        id: "r2",
        title: "Turbine Patron",
        minAmount: 500,
        description: "Name on donor wall at facility + guided tour",
        backers: 156,
        estimatedDelivery: "September 2025",
      },
    ],
    updates: [
      {
        id: "u1",
        title: "Environmental assessment complete",
        content: "Positive results from environmental impact study.",
        date: "2024-11-20",
      },
    ],
    impact: {
      co2Saved: 8500,
      homePowered: 3000,
      jobsCreated: 25,
    },
    featured: true,
  },
  {
    id: "biogas-cahul",
    title: "BioEnergy Cahul",
    shortDescription: "Agricultural waste to energy plant for rural community",
    description: `Convert agricultural waste into clean energy! This biogas facility will process organic waste from local farms, producing electricity and natural fertilizer while solving waste management challenges.

**Benefits**
- Waste-to-energy conversion
- Organic fertilizer production
- Reduced methane emissions
- Year-round energy production`,
    category: "biogas",
    location: "Cahul, Moldova",
    fundingGoal: 450000,
    fundingRaised: 315000,
    backers: 534,
    daysLeft: 18,
    image: "https://images.unsplash.com/photo-1595437193398-f24279553f4f?w=800",
    creator: {
      name: "AgriEnergy Co-op",
      avatar: "https://api.dicebear.com/7.x/initials/svg?seed=AEC",
      verified: true,
    },
    rewards: [
      {
        id: "r1",
        title: "Green Farmer",
        minAmount: 75,
        description: "Monthly project newsletter + recognition",
        backers: 234,
        estimatedDelivery: "February 2025",
      },
      {
        id: "r2",
        title: "Fertilizer Partner",
        minAmount: 300,
        description: "Free organic fertilizer delivery (1 tonne/year for 3 years)",
        backers: 89,
        estimatedDelivery: "August 2025",
      },
    ],
    updates: [],
    impact: {
      co2Saved: 450,
      homePowered: 200,
      jobsCreated: 8,
    },
    featured: false,
  },
  {
    id: "school-solar-ungheni",
    title: "Solar Schools Ungheni",
    shortDescription: "Solar panels for 10 schools reducing educational costs",
    description: `Power education with the sun! This project installs solar systems on 10 schools in Ungheni region, reducing energy costs and teaching children about renewable energy.

**Educational Impact**
- Real-time energy monitoring displays
- STEM curriculum integration
- Student ambassador program
- Annual savings reinvested in education`,
    category: "solar",
    location: "Ungheni, Moldova",
    fundingGoal: 180000,
    fundingRaised: 156000,
    backers: 892,
    daysLeft: 12,
    image: "https://images.unsplash.com/photo-1497440001374-f26997328c1b?w=800",
    creator: {
      name: "Education Green Fund",
      avatar: "https://api.dicebear.com/7.x/initials/svg?seed=EGF",
      verified: true,
    },
    rewards: [
      {
        id: "r1",
        title: "Future Builder",
        minAmount: 25,
        description: "Thank you card from students + digital certificate",
        backers: 456,
        estimatedDelivery: "January 2025",
      },
      {
        id: "r2",
        title: "Education Champion",
        minAmount: 150,
        description: "School visit invitation + commemorative plaque",
        backers: 123,
        estimatedDelivery: "May 2025",
      },
    ],
    updates: [
      {
        id: "u1",
        title: "First 3 schools installed!",
        content: "Solar panels are now generating power at 3 schools.",
        date: "2024-12-10",
      },
    ],
    impact: {
      co2Saved: 85,
      homePowered: 0,
      jobsCreated: 5,
    },
    featured: true,
  },
  {
    id: "efficiency-hospital-tiraspol",
    title: "Green Hospital Initiative",
    shortDescription: "Energy efficiency upgrades for regional medical center",
    description: `Reduce energy waste at Moldova's largest regional hospital. This project implements comprehensive energy efficiency measures including LED lighting, smart HVAC, and building insulation.

**Project Scope**
- Complete LED lighting retrofit
- Smart building management system
- Window and insulation upgrades
- Solar water heating`,
    category: "efficiency",
    location: "Tiraspol Region",
    fundingGoal: 320000,
    fundingRaised: 224000,
    backers: 445,
    daysLeft: 30,
    image: "https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=800",
    creator: {
      name: "Healthcare Sustainability Alliance",
      avatar: "https://api.dicebear.com/7.x/initials/svg?seed=HSA",
      verified: false,
    },
    rewards: [
      {
        id: "r1",
        title: "Health Guardian",
        minAmount: 50,
        description: "Recognition in hospital lobby + updates",
        backers: 267,
        estimatedDelivery: "March 2025",
      },
    ],
    updates: [],
    impact: {
      co2Saved: 320,
      homePowered: 0,
      jobsCreated: 12,
    },
    featured: false,
  },
  {
    id: "micro-hydro-orhei",
    title: "River Power Orhei",
    shortDescription: "Micro-hydro plant on Răut River for clean baseload power",
    description: `Tap into the consistent flow of the Răut River to generate reliable, clean electricity. This micro-hydro project provides 24/7 baseload power with minimal environmental impact.

**Technical Details**
- 500kW run-of-river installation
- Fish-friendly turbine design
- Automated operation
- 50+ year lifespan`,
    category: "hydro",
    location: "Orhei, Moldova",
    fundingGoal: 680000,
    fundingRaised: 340000,
    backers: 367,
    daysLeft: 52,
    image: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=800",
    creator: {
      name: "HydroMoldova",
      avatar: "https://api.dicebear.com/7.x/initials/svg?seed=HM",
      verified: true,
    },
    rewards: [
      {
        id: "r1",
        title: "River Guardian",
        minAmount: 100,
        description: "Exclusive river cleanup event invitation",
        backers: 189,
        estimatedDelivery: "June 2025",
      },
      {
        id: "r2",
        title: "Hydro Investor",
        minAmount: 2500,
        description: "2% annual revenue share for 10 years",
        backers: 34,
        estimatedDelivery: "January 2026",
      },
    ],
    updates: [],
    impact: {
      co2Saved: 650,
      homePowered: 400,
      jobsCreated: 6,
    },
    featured: false,
  },
];

export const categories = [
  { id: "all", name: "All Projects", icon: "Zap" },
  { id: "solar", name: "Solar", icon: "Sun" },
  { id: "wind", name: "Wind", icon: "Wind" },
  { id: "biogas", name: "Biogas", icon: "Leaf" },
  { id: "hydro", name: "Hydro", icon: "Droplets" },
  { id: "efficiency", name: "Efficiency", icon: "Lightbulb" },
] as const;

export const getFeaturedProjects = () => projects.filter((p) => p.featured);
export const getProjectById = (id: string) => projects.find((p) => p.id === id);
export const getProjectsByCategory = (category: string) =>
  category === "all" ? projects : projects.filter((p) => p.category === category);
