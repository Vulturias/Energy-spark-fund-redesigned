// Moldova Energy Data (2015-2024) - Parsed from official statistics

export interface MonthlyData {
  year: number;
  month: string;
  value: number;
}

export interface YearlyData {
  year: number;
  production: number;
  import: number;
  export: number;
  consumption: number;
}

// Electricity data (MWh)
export const electricityYearly: YearlyData[] = [
  { year: 2015, production: 934444, import: 18679, export: 0, consumption: 953123 },
  { year: 2016, production: 897184, import: 16, export: 0, consumption: 897200 },
  { year: 2017, production: 905597, import: 1122939, export: 0, consumption: 2028536 },
  { year: 2018, production: 931490, import: 946850, export: 0, consumption: 1878340 },
  { year: 2019, production: 880614, import: 544513, export: 0, consumption: 1425127 },
  { year: 2020, production: 1112787, import: 115665, export: 0, consumption: 1228452 },
  { year: 2021, production: 1060237, import: 97853, export: 0, consumption: 1158090 },
  { year: 2022, production: 844368, import: 1157645, export: 0, consumption: 2002013 },
  { year: 2023, production: 1030558, import: 590821, export: 0, consumption: 1621379 },
  { year: 2024, production: 1124510, import: 1180930, export: 0, consumption: 2305440 },
];

// Natural Gas data (thousand cubic meters)
export const naturalGasYearly: YearlyData[] = [
  { year: 2015, production: 0, import: 1008519, export: 0, consumption: 1008519 },
  { year: 2016, production: 0, import: 1165510, export: 0, consumption: 1165510 },
  { year: 2017, production: 0, import: 1149984, export: 0, consumption: 1149984 },
  { year: 2018, production: 0, import: 1070027, export: 0, consumption: 1070027 },
  { year: 2019, production: 0, import: 1089610, export: 0, consumption: 1089610 },
  { year: 2020, production: 0, import: 1111653, export: 0, consumption: 1111653 },
  { year: 2021, production: 0, import: 1098936, export: 0, consumption: 1098936 },
  { year: 2022, production: 0, import: 718598, export: 0, consumption: 718598 },
  { year: 2023, production: 0, import: 863979, export: 0, consumption: 863979 },
  { year: 2024, production: 0, import: 1076868, export: 0, consumption: 1076868 },
];

// Energy Balance by type (Terajoules) - 2023 data
export const energyBalanceByType = [
  { name: "Natural Gas", value: 24264, color: "hsl(var(--energy-gas))" },
  { name: "Petroleum Products", value: 47365, color: "hsl(var(--energy-thermal))" },
  { name: "Biofuels & Waste", value: 22865, color: "hsl(var(--energy-bio))" },
  { name: "Electricity", value: 13628, color: "hsl(var(--energy-wind))" },
  { name: "Coal", value: 2236, color: "hsl(var(--energy-coal))" },
];

// Energy Balance Yearly Trend (Terajoules)
export const energyBalanceYearly = [
  { year: 2010, total: 110336, coal: 4866, gas: 40283, petroleum: 32558, bio: 21427, electricity: 11202 },
  { year: 2011, total: 112296, coal: 5023, gas: 38988, petroleum: 34079, bio: 22610, electricity: 11596 },
  { year: 2012, total: 110127, coal: 4854, gas: 37094, petroleum: 32148, bio: 24107, electricity: 11924 },
  { year: 2013, total: 110853, coal: 6302, gas: 34991, petroleum: 32941, bio: 24458, electricity: 12161 },
  { year: 2014, total: 112047, coal: 4011, gas: 35614, petroleum: 33744, bio: 26428, electricity: 12250 },
  { year: 2015, total: 112652, coal: 4288, gas: 34197, petroleum: 34768, bio: 27265, electricity: 12134 },
  { year: 2016, total: 117162, coal: 3140, gas: 35105, petroleum: 37565, bio: 29214, electricity: 12138 },
  { year: 2017, total: 123235, coal: 4391, gas: 35062, petroleum: 39293, bio: 31991, electricity: 12498 },
  { year: 2018, total: 129394, coal: 3337, gas: 38157, petroleum: 42124, bio: 32913, electricity: 12863 },
  { year: 2019, total: 122999, coal: 4299, gas: 35868, petroleum: 42632, bio: 27184, electricity: 13016 },
  { year: 2020, total: 119736, coal: 3258, gas: 36548, petroleum: 39634, bio: 27612, electricity: 12684 },
  { year: 2021, total: 130658, coal: 3837, gas: 41782, petroleum: 44648, bio: 26837, electricity: 13554 },
  { year: 2022, total: 116126, coal: 2707, gas: 29774, petroleum: 46587, bio: 23039, electricity: 14019 },
  { year: 2023, total: 110361, coal: 2236, gas: 24264, petroleum: 47365, bio: 22865, electricity: 13628 },
];

// Key statistics for display
export const energyStats = {
  totalConsumption2023: 110361, // TJ
  renewableShare: 20.7, // %
  importDependency: 78.3, // %
  electricityProduction2024: 1124510, // MWh
  gasImport2024: 1076868, // thousand m³
  co2Reduction: 12.5, // % reduction target
};

// Monthly electricity production trends (sample 2024)
export const electricityMonthly2024 = [
  { month: "Jan", production: 173243, import: 109056 },
  { month: "Feb", production: 171536, import: 150821 },
  { month: "Mar", production: 145309, import: 274931 },
  { month: "Apr", production: 51887, import: 253263 },
  { month: "May", production: 47102, import: 200000 },
  { month: "Jun", production: 18852, import: 180000 },
  { month: "Jul", production: 18708, import: 170000 },
  { month: "Aug", production: 18498, import: 165000 },
  { month: "Sep", production: 21502, import: 155000 },
  { month: "Oct", production: 62929, import: 140000 },
  { month: "Nov", production: 141675, import: 120000 },
  { month: "Dec", production: 165421, import: 100000 },
];
