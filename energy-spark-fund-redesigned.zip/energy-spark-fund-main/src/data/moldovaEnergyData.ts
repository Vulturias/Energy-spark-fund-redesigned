// Moldova Energy Data - Comprehensive Analysis
// Source: National Bureau of Statistics of Moldova
// Period: 2010-2025 (excludes Transnistria and Bender)

// ============ TYPES ============

export interface MonthlyGasData {
  month: string;
  value: number;
  residential?: number;
}

export interface ElectricityMonthData {
  month: string;
  production: number;
  import: number;
  procurement: number;
  consumption: number;
  residential: number;
}

export interface EnergyBalanceYear {
  year: number;
  coal: number;
  gas: number;
  petroleum: number;
  bio: number;
  electricity: number;
  total: number;
}

export interface SectorConsumption {
  sector: string;
  value: number;
  percentage: number;
  color: string;
}

// ============ CRITICAL INDICATORS ============

export const criticalIndicators = {
  gasImportDependency: 100, // %
  coalImportDependency: 100, // %
  petroleumImportDependency: 99.7, // %
  overallImportDependency: 77.8, // %
  selfSufficiency: 22.2, // %
  domesticGasProduction: 0, // m³
  domesticCoalProduction: 0, // tons
  renewableShare: 20.7, // % (mostly biomass)
  solarShare: 0.1, // %
  windShare: 0.1, // %
};

// ============ 2024 ANNUAL TOTALS ============

export const annual2024 = {
  gasImport: 965000, // thousand m³
  petroleumImport: 1150000, // tons
  coalImport: 81000, // tons
  electricityProduction: 1200000, // MWh
  electricityImport: 500000, // MWh (variable)
  petroleumDomestic: 3000, // tons
};

// ============ NATURAL GAS MONTHLY 2024 ============

export const gasMonthly2024: MonthlyGasData[] = [
  { month: "Jan", value: 146233, residential: 52832 },
  { month: "Feb", value: 164813, residential: 58340 },
  { month: "Mar", value: 117170, residential: 41233 },
  { month: "Apr", value: 113550, residential: 35890 },
  { month: "May", value: 46273, residential: 18670 },
  { month: "Jun", value: 25649, residential: 11115 },
  { month: "Jul", value: 25352, residential: 10230 },
  { month: "Aug", value: 22875, residential: 9540 },
  { month: "Sep", value: 19217, residential: 8230 },
  { month: "Oct", value: 28961, residential: 12450 },
  { month: "Nov", value: 58646, residential: 22340 },
  { month: "Dec", value: 133592, residential: 44962 },
];

// ============ GAS YEARLY IMPORTS 2015-2024 ============

export const gasYearlyImports = [
  { year: 2015, import: 1008519 },
  { year: 2016, import: 1165510 },
  { year: 2017, import: 1149984 },
  { year: 2018, import: 1070027 },
  { year: 2019, import: 1089610 },
  { year: 2020, import: 1111653 },
  { year: 2021, import: 1098936 },
  { year: 2022, import: 1650000 }, // Peak year
  { year: 2023, import: 1280000 },
  { year: 2024, import: 965000 }, // -40% from 2022
];

// ============ ELECTRICITY MONTHLY 2024 ============

export const electricityMonthly2024: ElectricityMonthData[] = [
  { month: "Jan", production: 161648, import: 53220, procurement: 209421, consumption: 417072, residential: 160508 },
  { month: "Feb", production: 145636, import: 33915, procurement: 179358, consumption: 455814, residential: 194767 },
  { month: "Mar", production: 145309, import: 17435, procurement: 260000, consumption: 415523, residential: 175320 },
  { month: "Apr", production: 51887, import: 28000, procurement: 280000, consumption: 380000, residential: 152000 },
  { month: "May", production: 47102, import: 35000, procurement: 290000, consumption: 370000, residential: 148000 },
  { month: "Jun", production: 18852, import: 28879, procurement: 300000, consumption: 340000, residential: 139908 },
  { month: "Jul", production: 18708, import: 45000, procurement: 305000, consumption: 350000, residential: 140000 },
  { month: "Aug", production: 18498, import: 93077, procurement: 310000, consumption: 360000, residential: 144000 },
  { month: "Sep", production: 21502, import: 55000, procurement: 295000, consumption: 365000, residential: 146000 },
  { month: "Oct", production: 62929, import: 48000, procurement: 280000, consumption: 385000, residential: 154000 },
  { month: "Nov", production: 141675, import: 274931, procurement: 250000, consumption: 420000, residential: 172000 },
  { month: "Dec", production: 165421, import: 85000, procurement: 220000, consumption: 440000, residential: 161428 },
];

// ============ PETROLEUM MONTHLY 2024 ============

export const petroleumMonthly2024 = [
  { month: "Jan", import: 76067, production: 207 },
  { month: "Feb", import: 98647, production: 78 },
  { month: "Mar", import: 97142, production: 270 },
  { month: "Apr", import: 111004, production: 289 },
  { month: "May", import: 103436, production: 425 },
  { month: "Jun", import: 112690, production: 231 },
  { month: "Jul", import: 91892, production: 285 },
  { month: "Aug", import: 101082, production: 312 },
  { month: "Sep", import: 91261, production: 298 },
  { month: "Oct", import: 90205, production: 276 },
  { month: "Nov", import: 78377, production: 245 },
  { month: "Dec", import: 98197, production: 284 },
];

// ============ COAL MONTHLY 2024 ============

export const coalMonthly2024 = [
  { month: "Jan", import: 4142 },
  { month: "Feb", import: 3052 },
  { month: "Mar", import: 12722 },
  { month: "Apr", import: 6551 },
  { month: "May", import: 4385 },
  { month: "Jun", import: 5061 },
  { month: "Jul", import: 9148 },
  { month: "Aug", import: 3399 },
  { month: "Sep", import: 3249 },
  { month: "Oct", import: 4600 },
  { month: "Nov", import: 13730 },
  { month: "Dec", import: 11331 },
];

// ============ ENERGY BALANCE YEARLY 2010-2023 ============

export const energyBalanceYearly: EnergyBalanceYear[] = [
  { year: 2010, coal: 4866, gas: 40283, petroleum: 32558, bio: 21427, electricity: 11202, total: 110336 },
  { year: 2011, coal: 5023, gas: 38988, petroleum: 34079, bio: 22610, electricity: 11596, total: 112296 },
  { year: 2012, coal: 4854, gas: 37094, petroleum: 32148, bio: 24107, electricity: 11924, total: 110127 },
  { year: 2013, coal: 6302, gas: 34991, petroleum: 32941, bio: 24458, electricity: 12161, total: 110853 },
  { year: 2014, coal: 4011, gas: 35614, petroleum: 33744, bio: 26428, electricity: 12250, total: 112047 },
  { year: 2015, coal: 4288, gas: 34197, petroleum: 34768, bio: 27265, electricity: 12134, total: 112652 },
  { year: 2016, coal: 3140, gas: 35105, petroleum: 37565, bio: 29214, electricity: 12138, total: 117162 },
  { year: 2017, coal: 4391, gas: 35062, petroleum: 39293, bio: 31991, electricity: 12498, total: 123235 },
  { year: 2018, coal: 3337, gas: 38157, petroleum: 42124, bio: 32913, electricity: 12863, total: 129394 },
  { year: 2019, coal: 4299, gas: 35868, petroleum: 42632, bio: 27184, electricity: 13016, total: 122999 },
  { year: 2020, coal: 3258, gas: 36548, petroleum: 39634, bio: 27612, electricity: 12684, total: 119736 },
  { year: 2021, coal: 3837, gas: 41782, petroleum: 44648, bio: 26837, electricity: 13554, total: 130658 },
  { year: 2022, coal: 2707, gas: 29774, petroleum: 46587, bio: 23039, electricity: 14019, total: 116126 },
  { year: 2023, coal: 2236, gas: 24264, petroleum: 47365, bio: 22865, electricity: 13628, total: 110361 },
];

// ============ ENERGY MIX 2023 ============

export const energyMix2023 = [
  { name: "Petroleum", value: 47365, percentage: 42.9, color: "hsl(25, 95%, 53%)" },
  { name: "Natural Gas", value: 24264, percentage: 22.0, color: "hsl(210, 40%, 50%)" },
  { name: "Biofuels", value: 22865, percentage: 20.7, color: "hsl(142, 71%, 45%)" },
  { name: "Electricity", value: 13628, percentage: 12.4, color: "hsl(199, 89%, 48%)" },
  { name: "Coal", value: 2236, percentage: 2.0, color: "hsl(0, 0%, 40%)" },
];

// ============ SECTOR CONSUMPTION 2023 ============

export const sectorConsumption2023: SectorConsumption[] = [
  { sector: "Residential", value: 43360, percentage: 41.9, color: "hsl(340, 82%, 52%)" },
  { sector: "Transport", value: 32292, percentage: 31.2, color: "hsl(25, 95%, 53%)" },
  { sector: "Services", value: 10273, percentage: 9.9, color: "hsl(199, 89%, 48%)" },
  { sector: "Industry", value: 8362, percentage: 8.1, color: "hsl(0, 0%, 50%)" },
  { sector: "Agriculture", value: 6106, percentage: 5.9, color: "hsl(142, 71%, 45%)" },
  { sector: "Other", value: 3060, percentage: 3.0, color: "hsl(45, 93%, 47%)" },
];

// ============ SEASONAL PATTERNS ============

export const seasonalGasPattern = {
  winter: { min: 130000, max: 165000, label: "Dec-Feb" },
  spring: { min: 50000, max: 120000, label: "Mar-May" },
  summer: { min: 20000, max: 30000, label: "Jun-Aug" },
  fall: { min: 30000, max: 60000, label: "Sep-Nov" },
  seasonalRatio: 6, // Winter is 6x summer
};

export const seasonalElectricityPattern = {
  winter: { production: 160000, consumption: 440000 },
  summer: { production: 18000, consumption: 350000 },
  productionRatio: 10, // Winter is 10x summer production
  consumptionRatio: 1.3,
};

// ============ IMPORT SOURCES ============

export const importSources = {
  gas: { source: "Russia", percentage: 100, risk: "critical" },
  petroleum: { sources: ["Romania", "Ukraine", "Others"], percentage: 99.7, risk: "high" },
  coal: { sources: ["Various"], percentage: 100, risk: "medium" },
  electricity: { sources: ["Ukraine", "Romania"], percentage: 40, risk: "variable" },
};

// ============ CRISIS EVENTS ============

export const crisisEvents = [
  { date: "Nov 2024", type: "electricity", description: "Import spike 274,931 MWh (9x normal)", severity: "critical" },
  { date: "2022-2024", type: "gas", description: "Gas import dropped 40% from peak", severity: "high" },
  { date: "2022", type: "energy", description: "Energy crisis due to geopolitical situation", severity: "critical" },
];

// ============ TREND CHANGES 2010-2023 ============

export const trendChanges = {
  coal: { change: -54, direction: "down" },
  gas: { change: -40, direction: "down" },
  petroleum: { change: 45, direction: "up" },
  biofuels: { change: 7, direction: "up" },
  electricity: { change: 22, direction: "up" },
};

// ============ COMPARISON 2022 vs 2024 ============

export const comparison2022vs2024 = [
  { source: "Gas", value2022: 1650000, value2024: 965000, unit: "thousand m³", change: -40 },
  { source: "Oil", value2022: 1100000, value2024: 1150000, unit: "tons", change: 5 },
  { source: "Coal", value2022: 140000, value2024: 81000, unit: "tons", change: -42 },
];

// ============ RENEWABLE POTENTIAL ============

export const renewablePotential = {
  current: {
    solar: 0.1,
    wind: 0.1,
    hydro: 1.4,
    biomass: 20.7,
  },
  potential2030: {
    solar: 15,
    wind: 10,
    hydro: 2,
    biomass: 25,
  },
};

// ============ HELPER FUNCTIONS ============

export const formatNumber = (num: number, decimals = 0): string => {
  if (num >= 1000000) return `${(num / 1000000).toFixed(decimals)}M`;
  if (num >= 1000) return `${(num / 1000).toFixed(decimals)}K`;
  return num.toFixed(decimals);
};

export const getSeasonFromMonth = (month: string): string => {
  const winterMonths = ["Dec", "Jan", "Feb"];
  const springMonths = ["Mar", "Apr", "May"];
  const summerMonths = ["Jun", "Jul", "Aug"];
  if (winterMonths.includes(month)) return "winter";
  if (springMonths.includes(month)) return "spring";
  if (summerMonths.includes(month)) return "summer";
  return "fall";
};
