import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StatsCard } from "@/components/ui/stats-card";
import { MapDashboard } from "@/components/map/MapDashboard";
import {
  electricityYearly,
  naturalGasYearly,
  energyBalanceByType,
  energyBalanceYearly,
  electricityMonthly2024,
  energyStats,
} from "@/data/energyData";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import {
  Zap,
  Flame,
  TrendingDown,
  TrendingUp,
  Leaf,
  Import,
  Factory,
  Map,
} from "lucide-react";

const COLORS = [
  "hsl(210 40% 50%)",
  "hsl(25 95% 53%)",
  "hsl(142 71% 45%)",
  "hsl(199 89% 48%)",
  "hsl(0 0% 30%)",
];

export default function Analytics() {
  return (
    <Layout>
      {/* Header */}
      <section className="border-b border-border/50 py-8">
        <div className="container">
          <Badge variant="outline" className="mb-3 border-primary/30 text-primary">
            <Map className="mr-1.5 h-3 w-3" />
            Energy Analytics
          </Badge>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight mb-2">
            Moldova Energy Dashboard
          </h1>
          <p className="text-sm text-muted-foreground max-w-xl">
            Interactive 3D map with project locations and real-time energy data
          </p>
        </div>
      </section>

      {/* 3D Map Dashboard */}
      <section className="py-6">
        <div className="container">
          <MapDashboard />
        </div>
      </section>

      {/* Key Stats */}
      <section className="py-8 border-b border-border">
        <div className="container">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <StatsCard
              title="Total Consumption (2023)"
              value={`${(energyStats.totalConsumption2023 / 1000).toFixed(1)} PJ`}
              subtitle="Terajoules equivalent"
              icon={Zap}
            />
            <StatsCard
              title="Renewable Share"
              value={`${energyStats.renewableShare}%`}
              subtitle="of total energy mix"
              icon={Leaf}
              trend={{ value: 2.3, isPositive: true }}
            />
            <StatsCard
              title="Import Dependency"
              value={`${energyStats.importDependency}%`}
              subtitle="Energy imported"
              icon={Import}
            />
            <StatsCard
              title="Electricity Production"
              value={`${(energyStats.electricityProduction2024 / 1000).toFixed(0)} GWh`}
              subtitle="2024 total"
              icon={Factory}
            />
          </div>
        </div>
      </section>

      {/* Charts */}
      <section className="py-12">
        <div className="container">
          <Tabs defaultValue="overview" className="space-y-8">
            <TabsList className="grid w-full max-w-md grid-cols-3">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="electricity">Electricity</TabsTrigger>
              <TabsTrigger value="gas">Natural Gas</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-8">
              {/* Energy Balance by Type */}
              <div className="grid gap-6 lg:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Zap className="h-5 w-5 text-primary" />
                      Energy Consumption by Source (2023)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={energyBalanceByType}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) =>
                              `${name} (${(percent * 100).toFixed(0)}%)`
                            }
                            outerRadius={100}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {energyBalanceByType.map((entry, index) => (
                              <Cell
                                key={`cell-${index}`}
                                fill={COLORS[index % COLORS.length]}
                              />
                            ))}
                          </Pie>
                          <Tooltip
                            formatter={(value: number) => [
                              `${value.toLocaleString()} TJ`,
                              "Consumption",
                            ]}
                          />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-primary" />
                      Energy Balance Trend (2010-2023)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={energyBalanceYearly}>
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                          <XAxis dataKey="year" stroke="hsl(var(--muted-foreground))" />
                          <YAxis stroke="hsl(var(--muted-foreground))" />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: "hsl(var(--card))",
                              border: "1px solid hsl(var(--border))",
                              borderRadius: "8px",
                            }}
                          />
                          <Legend />
                          <Area
                            type="monotone"
                            dataKey="petroleum"
                            stackId="1"
                            stroke="hsl(25 95% 53%)"
                            fill="hsl(25 95% 53% / 0.6)"
                            name="Petroleum"
                          />
                          <Area
                            type="monotone"
                            dataKey="gas"
                            stackId="1"
                            stroke="hsl(210 40% 50%)"
                            fill="hsl(210 40% 50% / 0.6)"
                            name="Natural Gas"
                          />
                          <Area
                            type="monotone"
                            dataKey="bio"
                            stackId="1"
                            stroke="hsl(142 71% 45%)"
                            fill="hsl(142 71% 45% / 0.6)"
                            name="Biofuels"
                          />
                          <Area
                            type="monotone"
                            dataKey="electricity"
                            stackId="1"
                            stroke="hsl(199 89% 48%)"
                            fill="hsl(199 89% 48% / 0.6)"
                            name="Electricity"
                          />
                          <Area
                            type="monotone"
                            dataKey="coal"
                            stackId="1"
                            stroke="hsl(0 0% 40%)"
                            fill="hsl(0 0% 40% / 0.6)"
                            name="Coal"
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Key Insights */}
              <div className="grid gap-4 md:grid-cols-3">
                <Card className="border-energy-bio/30 bg-energy-bio/5">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <Leaf className="h-5 w-5 text-energy-bio" />
                      <span className="font-semibold">Biofuels Growing</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Biofuels and waste now account for 20.7% of Moldova's
                      energy mix, up from 19.4% in 2010.
                    </p>
                  </CardContent>
                </Card>
                <Card className="border-energy-gas/30 bg-energy-gas/5">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <Flame className="h-5 w-5 text-energy-gas" />
                      <span className="font-semibold">Gas Dependency</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Natural gas imports remain significant at 22% of total
                      consumption, but declining from 37% in 2010.
                    </p>
                  </CardContent>
                </Card>
                <Card className="border-primary/30 bg-primary/5">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <TrendingDown className="h-5 w-5 text-primary" />
                      <span className="font-semibold">Coal Phase-Out</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Coal usage has dropped 54% since 2010, from 4,866 TJ to
                      2,236 TJ in 2023.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Electricity Tab */}
            <TabsContent value="electricity" className="space-y-8">
              <div className="grid gap-6 lg:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Electricity Production vs Import (2015-2024)</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={electricityYearly}>
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                          <XAxis dataKey="year" stroke="hsl(var(--muted-foreground))" />
                          <YAxis stroke="hsl(var(--muted-foreground))" />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: "hsl(var(--card))",
                              border: "1px solid hsl(var(--border))",
                              borderRadius: "8px",
                            }}
                            formatter={(value: number) => [
                              `${(value / 1000).toFixed(0)} GWh`,
                            ]}
                          />
                          <Legend />
                          <Bar
                            dataKey="production"
                            fill="hsl(var(--primary))"
                            name="Production"
                            radius={[4, 4, 0, 0]}
                          />
                          <Bar
                            dataKey="import"
                            fill="hsl(var(--accent))"
                            name="Import"
                            radius={[4, 4, 0, 0]}
                          />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Monthly Electricity 2024</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={electricityMonthly2024}>
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                          <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" />
                          <YAxis stroke="hsl(var(--muted-foreground))" />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: "hsl(var(--card))",
                              border: "1px solid hsl(var(--border))",
                              borderRadius: "8px",
                            }}
                            formatter={(value: number) => [
                              `${(value / 1000).toFixed(0)} GWh`,
                            ]}
                          />
                          <Legend />
                          <Line
                            type="monotone"
                            dataKey="production"
                            stroke="hsl(var(--primary))"
                            strokeWidth={2}
                            dot={{ fill: "hsl(var(--primary))" }}
                            name="Production"
                          />
                          <Line
                            type="monotone"
                            dataKey="import"
                            stroke="hsl(var(--accent))"
                            strokeWidth={2}
                            dot={{ fill: "hsl(var(--accent))" }}
                            name="Import"
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-2">Key Insight</h3>
                  <p className="text-muted-foreground">
                    Moldova's electricity production peaks in winter months
                    (November-February) when the Cuciurgan power plant operates
                    at higher capacity for heating. During summer, imports
                    significantly increase due to reduced domestic generation.
                  </p>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Natural Gas Tab */}
            <TabsContent value="gas" className="space-y-8">
              <Card>
                <CardHeader>
                  <CardTitle>Natural Gas Import Trends (2015-2024)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={naturalGasYearly}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="year" stroke="hsl(var(--muted-foreground))" />
                        <YAxis stroke="hsl(var(--muted-foreground))" />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "hsl(var(--card))",
                            border: "1px solid hsl(var(--border))",
                            borderRadius: "8px",
                          }}
                          formatter={(value: number) => [
                            `${(value / 1000).toFixed(0)} million m³`,
                          ]}
                        />
                        <Area
                          type="monotone"
                          dataKey="import"
                          stroke="hsl(var(--energy-gas))"
                          fill="hsl(var(--energy-gas) / 0.3)"
                          strokeWidth={2}
                          name="Import"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <div className="grid gap-4 md:grid-cols-2">
                <Card className="border-energy-gas/30">
                  <CardContent className="p-6">
                    <h3 className="font-semibold mb-2">2022: Energy Crisis Impact</h3>
                    <p className="text-muted-foreground text-sm">
                      Gas imports dropped 35% in 2022 due to the energy crisis,
                      reaching a decade low of 719 million m³. This accelerated
                      diversification efforts.
                    </p>
                  </CardContent>
                </Card>
                <Card className="border-primary/30">
                  <CardContent className="p-6">
                    <h3 className="font-semibold mb-2">Diversification Progress</h3>
                    <p className="text-muted-foreground text-sm">
                      Moldova has increased alternative gas supplies and reduced
                      dependence on a single supplier, improving energy security.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Data Source */}
      <section className="py-8 border-t border-border bg-muted/30">
        <div className="container">
          <p className="text-sm text-muted-foreground text-center">
            Data source: National Bureau of Statistics of the Republic of Moldova
            (statistica.gov.md). Last updated: December 2024.
          </p>
        </div>
      </section>
    </Layout>
  );
}
