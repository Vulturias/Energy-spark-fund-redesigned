import { useParams, Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getProjectById } from "@/data/projectsData";
import {
  ArrowLeft,
  MapPin,
  Users,
  Clock,
  Leaf,
  Home,
  Briefcase,
  CheckCircle,
  Calendar,
  Share2,
  Heart,
} from "lucide-react";

export default function ProjectDetail() {
  const { id } = useParams();
  const project = getProjectById(id || "");

  if (!project) {
    return (
      <Layout>
        <div className="container py-20 text-center">
          <h1 className="text-2xl font-bold mb-4">Project Not Found</h1>
          <p className="text-muted-foreground mb-6">
            The project you're looking for doesn't exist or has been removed.
          </p>
          <Button asChild>
            <Link to="/projects">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Projects
            </Link>
          </Button>
        </div>
      </Layout>
    );
  }

  const fundingPercentage = Math.min(
    (project.fundingRaised / project.fundingGoal) * 100,
    100
  );

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "EUR",
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <Layout>
      {/* Breadcrumb */}
      <div className="border-b border-border">
        <div className="container py-4">
          <Link
            to="/projects"
            className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Projects
          </Link>
        </div>
      </div>

      {/* Hero */}
      <section className="border-b border-border">
        <div className="container py-8">
          <div className="grid gap-8 lg:grid-cols-5">
            {/* Image */}
            <div className="lg:col-span-3">
              <div className="relative aspect-video overflow-hidden rounded-xl">
                <img
                  src={project.image}
                  alt={project.title}
                  className="h-full w-full object-cover"
                />
                <Badge
                  className="absolute top-4 left-4 capitalize"
                  variant="secondary"
                >
                  {project.category}
                </Badge>
              </div>
            </div>

            {/* Funding Info */}
            <div className="lg:col-span-2">
              <Card className="sticky top-20">
                <CardContent className="p-6">
                  <div className="space-y-6">
                    <div>
                      <div className="flex items-baseline gap-2 mb-2">
                        <span className="text-3xl font-bold text-primary">
                          {formatCurrency(project.fundingRaised)}
                        </span>
                        <span className="text-muted-foreground">
                          / {formatCurrency(project.fundingGoal)}
                        </span>
                      </div>
                      <Progress value={fundingPercentage} className="h-3 mb-2" />
                      <p className="text-sm text-muted-foreground">
                        {Math.round(fundingPercentage)}% funded
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 rounded-lg bg-muted">
                        <Users className="h-5 w-5 mx-auto mb-1 text-primary" />
                        <p className="font-semibold">
                          {project.backers.toLocaleString()}
                        </p>
                        <p className="text-xs text-muted-foreground">Backers</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-muted">
                        <Clock className="h-5 w-5 mx-auto mb-1 text-primary" />
                        <p className="font-semibold">{project.daysLeft}</p>
                        <p className="text-xs text-muted-foreground">Days Left</p>
                      </div>
                    </div>

                    <Button className="w-full" size="lg">
                      Back This Project
                    </Button>

                    <div className="flex gap-2">
                      <Button variant="outline" className="flex-1" size="sm">
                        <Heart className="h-4 w-4 mr-2" />
                        Save
                      </Button>
                      <Button variant="outline" className="flex-1" size="sm">
                        <Share2 className="h-4 w-4 mr-2" />
                        Share
                      </Button>
                    </div>

                    <Separator />

                    {/* Creator */}
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src={project.creator.avatar} />
                        <AvatarFallback>
                          {project.creator.name.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{project.creator.name}</span>
                          {project.creator.verified && (
                            <CheckCircle className="h-4 w-4 text-primary" />
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Project Creator
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-12">
        <div className="container">
          <div className="grid gap-8 lg:grid-cols-5">
            <div className="lg:col-span-3">
              {/* Title & Meta */}
              <div className="mb-8">
                <h1 className="text-3xl font-bold tracking-tight mb-3">
                  {project.title}
                </h1>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1.5">
                    <MapPin className="h-4 w-4" />
                    <span>{project.location}</span>
                  </div>
                </div>
              </div>

              {/* Tabs */}
              <Tabs defaultValue="about" className="space-y-8">
                <TabsList>
                  <TabsTrigger value="about">About</TabsTrigger>
                  <TabsTrigger value="rewards">Rewards</TabsTrigger>
                  <TabsTrigger value="updates">
                    Updates ({project.updates.length})
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="about" className="space-y-6">
                  {/* Impact Stats */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Environmental Impact</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-3 gap-4">
                        <div className="text-center p-4 rounded-lg bg-muted">
                          <Leaf className="h-6 w-6 mx-auto mb-2 text-energy-bio" />
                          <p className="text-2xl font-bold">
                            {project.impact.co2Saved}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Tonnes CO₂/year
                          </p>
                        </div>
                        {project.impact.homePowered > 0 && (
                          <div className="text-center p-4 rounded-lg bg-muted">
                            <Home className="h-6 w-6 mx-auto mb-2 text-energy-solar" />
                            <p className="text-2xl font-bold">
                              {project.impact.homePowered}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              Homes Powered
                            </p>
                          </div>
                        )}
                        <div className="text-center p-4 rounded-lg bg-muted">
                          <Briefcase className="h-6 w-6 mx-auto mb-2 text-primary" />
                          <p className="text-2xl font-bold">
                            {project.impact.jobsCreated}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Jobs Created
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Description */}
                  <div className="prose prose-sm max-w-none">
                    {project.description.split("\n\n").map((paragraph, i) => (
                      <p key={i} className="text-muted-foreground">
                        {paragraph}
                      </p>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="rewards" className="space-y-4">
                  {project.rewards.map((reward) => (
                    <Card key={reward.id} className="overflow-hidden">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <Badge variant="outline" className="mb-2">
                              {formatCurrency(reward.minAmount)} or more
                            </Badge>
                            <h3 className="font-semibold text-lg">
                              {reward.title}
                            </h3>
                          </div>
                        </div>
                        <p className="text-muted-foreground mb-4">
                          {reward.description}
                        </p>
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex items-center gap-1.5 text-muted-foreground">
                            <Users className="h-4 w-4" />
                            <span>{reward.backers} backers</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-muted-foreground">
                            <Calendar className="h-4 w-4" />
                            <span>Est. {reward.estimatedDelivery}</span>
                          </div>
                        </div>
                        <Button className="w-full mt-4" variant="outline">
                          Select This Reward
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </TabsContent>

                <TabsContent value="updates" className="space-y-4">
                  {project.updates.length > 0 ? (
                    project.updates.map((update) => (
                      <Card key={update.id}>
                        <CardContent className="p-6">
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                            <Calendar className="h-4 w-4" />
                            <span>
                              {new Date(update.date).toLocaleDateString("en-US", {
                                year: "numeric",
                                month: "long",
                                day: "numeric",
                              })}
                            </span>
                          </div>
                          <h3 className="font-semibold text-lg mb-2">
                            {update.title}
                          </h3>
                          <p className="text-muted-foreground">{update.content}</p>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <div className="text-center py-12">
                      <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="font-semibold mb-2">No updates yet</h3>
                      <p className="text-muted-foreground">
                        The project creator hasn't posted any updates.
                      </p>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </div>

            {/* Sidebar - visible on lg+ */}
            <div className="lg:col-span-2 hidden lg:block">
              {/* Empty space for sticky funding card on mobile */}
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
