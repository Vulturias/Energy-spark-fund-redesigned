import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sun,
  Zap,
  Leaf,
  TrendingUp,
  Home,
  Calculator,
  ArrowRight,
  CheckCircle,
} from "lucide-react";

const regions = [
  "Chișinău",
  "Bălți",
  "Cahul",
  "Ungheni",
  "Orhei",
  "Soroca",
  "Edineț",
  "Comrat",
  "Other",
];

// Average sun hours per region (simplified)
const sunHoursMap: Record<string, number> = {
  Chișinău: 2100,
  Bălți: 2050,
  Cahul: 2150,
  Ungheni: 2080,
  Orhei: 2100,
  Soroca: 2000,
  Edineț: 1980,
  Comrat: 2120,
  Other: 2050,
};

export default function SolarCalculator() {
  const [region, setRegion] = useState("");
  const [roofArea, setRoofArea] = useState([50]);
  const [monthlyBill, setMonthlyBill] = useState("");
  const [email, setEmail] = useState("");
  const [calculated, setCalculated] = useState(false);

  // Calculation logic
  const roofSize = roofArea[0];
  const usableRoof = roofSize * 0.7; // 70% usable
  const panelsCount = Math.floor(usableRoof / 1.7); // ~1.7m² per panel
  const systemSize = panelsCount * 0.4; // 400W per panel
  const sunHours = sunHoursMap[region] || 2050;
  const annualProduction = systemSize * sunHours; // kWh/year
  const monthlyProduction = annualProduction / 12;

  const electricityPrice = 0.12; // EUR/kWh average
  const annualSavings = annualProduction * electricityPrice;
  const monthlySavings = annualSavings / 12;

  const systemCost = systemSize * 800; // EUR per kW installed
  const paybackYears = systemCost / annualSavings;

  const co2Saved = annualProduction * 0.0004; // tonnes CO2 per kWh

  const handleCalculate = () => {
    if (region && roofSize > 0) {
      setCalculated(true);
    }
  };

  const handleReset = () => {
    setCalculated(false);
  };

  return (
    <Layout>
      {/* Header */}
      <section className="border-b border-border bg-muted/30 py-12">
        <div className="container">
          <Badge variant="outline" className="mb-3">
            <Sun className="mr-1.5 h-3.5 w-3.5" />
            Solar Calculator
          </Badge>
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">
            Calculate Your Solar Potential
          </h1>
          <p className="text-muted-foreground max-w-2xl">
            Find out how much you could save with solar panels on your home.
            Get personalized estimates based on your location and energy usage.
          </p>
        </div>
      </section>

      {/* Calculator */}
      <section className="py-12">
        <div className="container">
          <div className="grid gap-8 lg:grid-cols-2">
            {/* Input Form */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calculator className="h-5 w-5 text-primary" />
                    Your Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Region */}
                  <div className="space-y-2">
                    <Label htmlFor="region">Your Region</Label>
                    <Select value={region} onValueChange={setRegion}>
                      <SelectTrigger id="region">
                        <SelectValue placeholder="Select your region" />
                      </SelectTrigger>
                      <SelectContent>
                        {regions.map((r) => (
                          <SelectItem key={r} value={r}>
                            {r}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Roof Area */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label>Available Roof Area</Label>
                      <span className="text-sm font-medium">{roofSize} m²</span>
                    </div>
                    <Slider
                      value={roofArea}
                      onValueChange={setRoofArea}
                      min={10}
                      max={200}
                      step={5}
                      className="w-full"
                    />
                    <p className="text-xs text-muted-foreground">
                      Estimate the south-facing roof area available for panels
                    </p>
                  </div>

                  {/* Monthly Bill */}
                  <div className="space-y-2">
                    <Label htmlFor="bill">Monthly Electricity Bill (optional)</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                        €
                      </span>
                      <Input
                        id="bill"
                        type="number"
                        placeholder="75"
                        value={monthlyBill}
                        onChange={(e) => setMonthlyBill(e.target.value)}
                        className="pl-8"
                      />
                    </div>
                  </div>

                  <Button
                    onClick={handleCalculate}
                    disabled={!region}
                    className="w-full"
                    size="lg"
                  >
                    Calculate Savings
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>

              {/* Info Card */}
              <Card className="mt-6 border-primary/20 bg-primary/5">
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-2">Why Go Solar in Moldova?</h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                      <span>2,000+ hours of sunshine per year</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                      <span>Net metering available for grid connection</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                      <span>Reduce dependency on imported electricity</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                      <span>25+ year panel lifespan</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>

            {/* Results */}
            <div>
              {calculated ? (
                <div className="space-y-6 animate-fade-in">
                  <Card className="border-primary">
                    <CardHeader className="bg-primary text-primary-foreground rounded-t-lg">
                      <CardTitle className="flex items-center gap-2">
                        <Sun className="h-5 w-5" />
                        Your Solar Estimate
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="grid grid-cols-2 gap-4 mb-6">
                        <div className="text-center p-4 rounded-lg bg-muted">
                          <p className="text-3xl font-bold text-primary">
                            {systemSize.toFixed(1)}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            kW System Size
                          </p>
                        </div>
                        <div className="text-center p-4 rounded-lg bg-muted">
                          <p className="text-3xl font-bold text-primary">
                            {panelsCount}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Solar Panels
                          </p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                          <div className="flex items-center gap-3">
                            <Zap className="h-5 w-5 text-energy-solar" />
                            <span>Annual Production</span>
                          </div>
                          <span className="font-semibold">
                            {annualProduction.toLocaleString(undefined, {
                              maximumFractionDigits: 0,
                            })}{" "}
                            kWh
                          </span>
                        </div>

                        <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                          <div className="flex items-center gap-3">
                            <TrendingUp className="h-5 w-5 text-primary" />
                            <span>Annual Savings</span>
                          </div>
                          <span className="font-semibold text-primary">
                            €{annualSavings.toLocaleString(undefined, {
                              maximumFractionDigits: 0,
                            })}
                          </span>
                        </div>

                        <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                          <div className="flex items-center gap-3">
                            <Home className="h-5 w-5 text-energy-wind" />
                            <span>Estimated System Cost</span>
                          </div>
                          <span className="font-semibold">
                            €{systemCost.toLocaleString(undefined, {
                              maximumFractionDigits: 0,
                            })}
                          </span>
                        </div>

                        <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                          <div className="flex items-center gap-3">
                            <Calculator className="h-5 w-5 text-energy-thermal" />
                            <span>Payback Period</span>
                          </div>
                          <span className="font-semibold">
                            {paybackYears.toFixed(1)} years
                          </span>
                        </div>

                        <div className="flex items-center justify-between p-3 rounded-lg bg-energy-bio/10 border border-energy-bio/20">
                          <div className="flex items-center gap-3">
                            <Leaf className="h-5 w-5 text-energy-bio" />
                            <span>CO₂ Saved Annually</span>
                          </div>
                          <span className="font-semibold text-energy-bio">
                            {co2Saved.toFixed(1)} tonnes
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Lead Capture */}
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-semibold mb-2">Get a Personalized Quote</h3>
                      <p className="text-sm text-muted-foreground mb-4">
                        Enter your email to receive a detailed proposal from our
                        verified solar installers.
                      </p>
                      <div className="flex gap-2">
                        <Input
                          type="email"
                          placeholder="your@email.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="flex-1"
                        />
                        <Button>Get Quote</Button>
                      </div>
                    </CardContent>
                  </Card>

                  <Button variant="outline" onClick={handleReset} className="w-full">
                    Calculate Again
                  </Button>
                </div>
              ) : (
                <Card className="h-full flex items-center justify-center min-h-[400px]">
                  <CardContent className="text-center p-6">
                    <Sun className="h-16 w-16 text-muted-foreground/30 mx-auto mb-4" />
                    <h3 className="font-semibold text-lg mb-2">
                      Enter Your Details
                    </h3>
                    <p className="text-muted-foreground max-w-sm">
                      Fill in the form on the left to see your personalized solar
                      energy estimate and potential savings.
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-12 border-t border-border bg-muted/30">
        <div className="container text-center">
          <h2 className="text-2xl font-bold mb-3">Ready to Go Solar?</h2>
          <p className="text-muted-foreground mb-6 max-w-lg mx-auto">
            Join thousands of Moldovans who have already made the switch to clean,
            renewable energy. Start your solar journey today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg">Find an Installer</Button>
            <Button size="lg" variant="outline">
              Browse Solar Projects
            </Button>
          </div>
        </div>
      </section>
    </Layout>
  );
}
