import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { InvestmentCard } from "@/components/projects/InvestmentCard";
import { MoldovaMap } from "@/components/map/MoldovaMap";
import { EnergyDashboardFull } from "@/components/dashboard/EnergyDashboardFull";
import { HeroMetrics } from "@/components/dashboard/HeroMetrics";
import { getFeaturedProjects, projects } from "@/data/projectsData";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  Zap,
  Sun,
  Wind,
  Leaf,
  Shield,
  Users,
  BarChart3,
  Lightbulb,
} from "lucide-react";

const featuredProjects = getFeaturedProjects();

export default function Index() {
  // Split projects for left and right sides
  const leftProjects = projects.slice(0, 3);
  const rightProjects = projects.slice(3, 6);

  return (
    <Layout>
      {/* Hero Metrics - Main Infographics at Top */}
      <section className="py-4 md:py-6 border-b border-white/5">
        <div className="max-w-[1800px] mx-auto px-4 sm:px-6 lg:px-8">
          <HeroMetrics />
        </div>
      </section>

      {/* Energy Dashboard - Detailed Analytics */}
      <section className="py-6 md:py-8 bg-gradient-to-b from-transparent via-black/20 to-transparent border-b border-white/5">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
          <EnergyDashboardFull />
        </div>
      </section>

      {/* Central Map with Projects on Sides */}
      <section className="py-8 md:py-10">
        <div className="max-w-[1800px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-6">
            <Badge variant="outline" className="mb-2 border-primary/30 text-primary backdrop-blur-sm bg-primary/10">
              <Zap className="mr-1.5 h-3.5 w-3.5" />
              Live Investment Projects
            </Badge>
            <h2 className="text-xl md:text-2xl font-bold tracking-tight">
              Invest in Moldova's Energy Independence
            </h2>
            <p className="text-muted-foreground mt-1 text-sm">
              Click map pins to explore • Cards show live funding data
            </p>
          </div>

          {/* Three column layout: Projects - Map - Projects */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 lg:gap-4 xl:gap-6">
            {/* Left Projects */}
            <div className="lg:col-span-3 space-y-3 order-2 lg:order-1">
              {leftProjects.map((project) => (
                <InvestmentCard key={project.id} project={project} compact />
              ))}
            </div>

            {/* Central Map */}
            <div className="lg:col-span-6 order-1 lg:order-2">
              <div className="glass relative rounded-lg overflow-hidden shadow-glow">
                <div className="p-3">
                  <div className="h-[450px] lg:h-[550px]">
                    <MoldovaMap />
                  </div>
                  
                  {/* Map legend */}
                  <div className="flex items-center justify-center gap-4 mt-3 text-[10px] text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Sun className="h-3 w-3 text-amber-400" />
                      <span>Solar</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Wind className="h-3 w-3 text-sky-400" />
                      <span>Wind</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Leaf className="h-3 w-3 text-emerald-400" />
                      <span>Biogas</span>
                    </div>
                    <div className="flex items-center gap-1 hidden sm:flex">
                      <div className="h-2.5 w-2.5 rounded-full bg-cyan-400" />
                      <span>Hydro</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Projects */}
            <div className="lg:col-span-3 space-y-3 order-3">
              {rightProjects.map((project) => (
                <InvestmentCard key={project.id} project={project} compact />
              ))}
            </div>
          </div>

          <div className="mt-6 text-center">
            <Button asChild variant="outline" size="lg" className="border-primary/30 backdrop-blur-sm hover:bg-primary/10">
              <Link to="/projects">
                View All Projects
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Solar Calculator CTA */}
      <section className="py-8 md:py-10 bg-gradient-to-r from-amber-500/5 via-orange-500/5 to-amber-500/5 border-y border-white/5">
        <div className="container">
          <div className="mx-auto max-w-2xl text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-lg bg-amber-500/20 mx-auto mb-4 backdrop-blur-sm glow-solar">
              <Lightbulb className="h-7 w-7 text-amber-400" />
            </div>
            <h2 className="text-xl md:text-2xl font-bold tracking-tight mb-3">
              Calculate Your Solar Potential
            </h2>
            <p className="text-muted-foreground mb-5 text-sm">
              Estimate your savings and discover how much you could contribute to Moldova's energy independence.
            </p>
            <Button
              size="lg"
              asChild
              className="bg-amber-500 text-black font-semibold hover:bg-amber-400 shadow-glow-solar"
            >
              <Link to="/calculator">
                Try Solar Calculator
                <Sun className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-8 md:py-10">
        <div className="container">
          <div className="text-center mb-8">
            <Badge variant="outline" className="mb-2 border-border/50 backdrop-blur-sm bg-white/5 text-sm">
              Why BUCEFALUS
            </Badge>
            <h2 className="text-xl md:text-2xl font-bold tracking-tight">
              Built on Trust & Transparency
            </h2>
          </div>

          <div className="grid gap-3 md:grid-cols-3">
            <div className="glass rounded-lg p-5 text-center transition-all hover:-translate-y-0.5 hover:shadow-glow">
              <Shield className="h-9 w-9 text-primary mx-auto mb-3" />
              <h3 className="font-semibold text-base mb-2">Verified Projects</h3>
              <p className="text-xs text-muted-foreground">
                Every project undergoes rigorous verification before listing.
              </p>
            </div>
            <div className="glass rounded-lg p-5 text-center transition-all hover:-translate-y-0.5 hover:shadow-glow-accent">
              <Users className="h-9 w-9 text-accent mx-auto mb-3" />
              <h3 className="font-semibold text-base mb-2">Community Driven</h3>
              <p className="text-xs text-muted-foreground">
                Join over 12,500 Moldovans investing in a sustainable future.
              </p>
            </div>
            <div className="glass rounded-lg p-5 text-center transition-all hover:-translate-y-0.5 hover:shadow-glow-solar">
              <BarChart3 className="h-9 w-9 text-amber-400 mx-auto mb-3" />
              <h3 className="font-semibold text-base mb-2">Real Data</h3>
              <p className="text-xs text-muted-foreground">
                Access official energy statistics for informed decisions.
              </p>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
