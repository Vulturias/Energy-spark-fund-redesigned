import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ProjectCard } from "@/components/projects/ProjectCard";
import { projects, categories, getProjectsByCategory } from "@/data/projectsData";
import { Search, SlidersHorizontal, Sun, Wind, Leaf, Droplets, Lightbulb, Zap } from "lucide-react";
import { cn } from "@/lib/utils";

const iconMap = {
  Zap: Zap,
  Sun: Sun,
  Wind: Wind,
  Leaf: Leaf,
  Droplets: Droplets,
  Lightbulb: Lightbulb,
};

export default function Projects() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredProjects = getProjectsByCategory(selectedCategory).filter(
    (project) =>
      project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.shortDescription.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalRaised = projects.reduce((sum, p) => sum + p.fundingRaised, 0);
  const totalBackers = projects.reduce((sum, p) => sum + p.backers, 0);

  return (
    <Layout>
      {/* Header */}
      <section className="border-b border-border bg-muted/30 py-12">
        <div className="container">
          <Badge variant="outline" className="mb-3">
            Crowdfunding
          </Badge>
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">
            Energy Projects
          </h1>
          <p className="text-muted-foreground max-w-2xl mb-6">
            Discover and invest in renewable energy projects across Moldova.
            Every contribution helps build a sustainable future.
          </p>
          <div className="flex flex-wrap gap-4 text-sm">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-primary">
                €{(totalRaised / 1000000).toFixed(1)}M
              </span>
              <span className="text-muted-foreground">raised</span>
            </div>
            <div className="h-4 w-px bg-border" />
            <div className="flex items-center gap-2">
              <span className="font-semibold text-primary">{projects.length}</span>
              <span className="text-muted-foreground">active projects</span>
            </div>
            <div className="h-4 w-px bg-border" />
            <div className="flex items-center gap-2">
              <span className="font-semibold text-primary">
                {totalBackers.toLocaleString()}
              </span>
              <span className="text-muted-foreground">backers</span>
            </div>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="border-b border-border py-4 sticky top-16 bg-background/95 backdrop-blur z-40">
        <div className="container">
          <div className="flex flex-col md:flex-row gap-4 justify-between">
            {/* Search */}
            <div className="relative max-w-sm flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search projects..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>

            {/* Category Filters */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0">
              {categories.map((category) => {
                const Icon = iconMap[category.icon as keyof typeof iconMap];
                return (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(category.id)}
                    className={cn(
                      "shrink-0",
                      selectedCategory === category.id && "shadow-md"
                    )}
                  >
                    <Icon className="h-4 w-4 mr-1.5" />
                    {category.name}
                  </Button>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="py-12">
        <div className="container">
          {filteredProjects.length > 0 ? (
            <>
              <p className="text-sm text-muted-foreground mb-6">
                Showing {filteredProjects.length} project
                {filteredProjects.length !== 1 ? "s" : ""}
                {selectedCategory !== "all" && ` in ${selectedCategory}`}
                {searchQuery && ` matching "${searchQuery}"`}
              </p>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {filteredProjects.map((project) => (
                  <ProjectCard key={project.id} project={project} />
                ))}
              </div>
            </>
          ) : (
            <div className="text-center py-16">
              <SlidersHorizontal className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-semibold text-lg mb-2">No projects found</h3>
              <p className="text-muted-foreground mb-4">
                Try adjusting your filters or search query.
              </p>
              <Button
                variant="outline"
                onClick={() => {
                  setSelectedCategory("all");
                  setSearchQuery("");
                }}
              >
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Start Project CTA */}
      <section className="py-12 border-t border-border bg-muted/30">
        <div className="container text-center">
          <h2 className="text-2xl font-bold mb-3">Have a Project Idea?</h2>
          <p className="text-muted-foreground mb-6 max-w-lg mx-auto">
            Launch your renewable energy project on BUCEFALUS and connect with
            thousands of supporters ready to fund Moldova's sustainable future.
          </p>
          <Button size="lg">Start Your Campaign</Button>
        </div>
      </section>
    </Layout>
  );
}
