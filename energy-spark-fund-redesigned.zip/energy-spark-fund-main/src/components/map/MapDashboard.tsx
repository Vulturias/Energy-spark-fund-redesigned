import { MoldovaMap } from "./MoldovaMap";
import { SideStatCard } from "./SideStatCard";
import { energyStats } from "@/data/energyData";
import { projects } from "@/data/projectsData";
import {
  Zap,
  Flame,
  Leaf,
  TrendingUp,
  Sun,
  Wind,
  Droplets,
  Factory,
  Users,
  Target,
  Battery,
  Gauge,
} from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";

const totalRaised = projects.reduce((sum, p) => sum + p.fundingRaised, 0);
const totalBackers = projects.reduce((sum, p) => sum + p.backers, 0);
const totalCO2 = projects.reduce((sum, p) => sum + p.impact.co2Saved, 0);

const energyMix = [
  { name: "Solar", value: 45, color: "#FACC15" },
  { name: "Wind", value: 25, color: "#0EA5E9" },
  { name: "Hydro", value: 10, color: "#3B82F6" },
  { name: "Bio", value: 20, color: "#22C55E" },
];

export function MapDashboard() {
  return (
    <div className="relative w-full min-h-[700px] rounded-2xl bg-card/30 border border-border/50 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />

      {/* Grid pattern */}
      <div className="absolute inset-0 opacity-5">
        <svg className="h-full w-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="dashboard-grid" width="50" height="50" patternUnits="userSpaceOnUse">
              <path d="M 50 0 L 0 0 0 50" fill="none" stroke="currentColor" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#dashboard-grid)" />
        </svg>
      </div>

      <div className="relative grid grid-cols-12 gap-4 p-4 lg:p-6 h-full">
        {/* Left Panel - Stats */}
        <div className="col-span-12 lg:col-span-3 space-y-3 order-2 lg:order-1">
          <div className="text-xs font-semibold text-muted-foreground mb-4 flex items-center gap-2">
            <Gauge className="h-4 w-4 text-primary" />
            ENERGY METRICS
          </div>

          <SideStatCard
            title="Electricity Production"
            value="1,124 GWh"
            subtitle="2024 Total"
            icon={Zap}
            trend={{ value: 9.1, isPositive: true }}
            color="primary"
            position="left"
          />

          <SideStatCard
            title="Natural Gas Import"
            value="1,076M m³"
            subtitle="2024 Total"
            icon={Flame}
            trend={{ value: 24.6, isPositive: true }}
            color="solar"
            position="left"
          />

          <SideStatCard
            title="Renewable Share"
            value={`${energyStats.renewableShare}%`}
            subtitle="of consumption"
            icon={Leaf}
            trend={{ value: 2.3, isPositive: true }}
            color="accent"
            position="left"
          />

          <SideStatCard
            title="Import Dependency"
            value={`${energyStats.importDependency}%`}
            subtitle="energy imported"
            icon={TrendingUp}
            color="wind"
            position="left"
          />

          {/* Mini pie chart */}
          <div className="bg-card/60 backdrop-blur-sm rounded-xl p-4 border border-border/50 border-l-2 border-l-primary">
            <div className="flex items-center gap-2 mb-3">
              <Battery className="h-4 w-4 text-primary" />
              <span className="text-xs text-muted-foreground font-medium">Renewable Potential</span>
            </div>
            <div className="h-24">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={energyMix}
                    cx="50%"
                    cy="50%"
                    innerRadius={25}
                    outerRadius={40}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {energyMix.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-1 mt-2">
              {energyMix.map((item) => (
                <div key={item.name} className="flex items-center gap-1.5 text-[10px]">
                  <div className="h-2 w-2 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-muted-foreground">{item.name}</span>
                  <span className="font-medium">{item.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Center - 3D Map */}
        <div className="col-span-12 lg:col-span-6 order-1 lg:order-2">
          <div className="text-center mb-4">
            <h2 className="text-xl font-bold">Moldova Energy Projects Map</h2>
            <p className="text-xs text-muted-foreground">Interactive 3D visualization • Hover over pins for details</p>
          </div>
          <div className="h-[400px] lg:h-[550px]">
            <MoldovaMap />
          </div>
        </div>

        {/* Right Panel - Project Stats */}
        <div className="col-span-12 lg:col-span-3 space-y-3 order-3">
          <div className="text-xs font-semibold text-muted-foreground mb-4 flex items-center gap-2">
            <Factory className="h-4 w-4 text-accent" />
            PROJECT METRICS
          </div>

          <SideStatCard
            title="Total Raised"
            value={`€${(totalRaised / 1000000).toFixed(1)}M`}
            subtitle="across all projects"
            icon={Target}
            trend={{ value: 15.2, isPositive: true }}
            color="accent"
            position="right"
          />

          <SideStatCard
            title="Community Backers"
            value={totalBackers.toLocaleString()}
            subtitle="investors"
            icon={Users}
            color="primary"
            position="right"
          />

          <SideStatCard
            title="CO₂ Saved"
            value={`${(totalCO2 / 1000).toFixed(1)}K t`}
            subtitle="tonnes annually"
            icon={Leaf}
            trend={{ value: 8.5, isPositive: true }}
            color="bio"
            position="right"
          />

          {/* Project types breakdown */}
          <div className="bg-card/60 backdrop-blur-sm rounded-xl p-4 border border-border/50 border-r-2 border-r-accent">
            <div className="flex items-center gap-2 mb-3">
              <Factory className="h-4 w-4 text-accent" />
              <span className="text-xs text-muted-foreground font-medium">Projects by Type</span>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sun className="h-4 w-4 text-energy-solar" />
                  <span className="text-xs">Solar</span>
                </div>
                <span className="text-xs font-bold text-energy-solar">2</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Wind className="h-4 w-4 text-energy-wind" />
                  <span className="text-xs">Wind</span>
                </div>
                <span className="text-xs font-bold text-energy-wind">1</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Leaf className="h-4 w-4 text-energy-bio" />
                  <span className="text-xs">Biogas</span>
                </div>
                <span className="text-xs font-bold text-energy-bio">1</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Droplets className="h-4 w-4 text-energy-hydro" />
                  <span className="text-xs">Hydro</span>
                </div>
                <span className="text-xs font-bold text-energy-hydro">1</span>
              </div>
            </div>
          </div>

          {/* Live indicator */}
          <div className="bg-card/60 backdrop-blur-sm rounded-xl p-4 border border-border/50 border-r-2 border-r-primary">
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-accent animate-pulse" />
              <span className="text-xs text-muted-foreground">Live data updates</span>
            </div>
            <p className="text-[10px] text-muted-foreground mt-2">
              Last updated: {new Date().toLocaleTimeString()}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
