import { useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls, Text, Html } from "@react-three/drei";
import * as THREE from "three";
import { projects } from "@/data/projectsData";

// Moldova shape - simplified polygon coordinates (normalized)
const moldovaShape = [
  [0, 0.95], [0.15, 1], [0.3, 0.98], [0.45, 0.92], [0.55, 0.85],
  [0.65, 0.78], [0.72, 0.7], [0.78, 0.6], [0.82, 0.5], [0.85, 0.4],
  [0.88, 0.3], [0.85, 0.2], [0.8, 0.12], [0.7, 0.05], [0.55, 0],
  [0.4, 0.02], [0.25, 0.08], [0.15, 0.18], [0.08, 0.3], [0.05, 0.45],
  [0.03, 0.6], [0.02, 0.75], [0, 0.85],
];

// Project locations on map (normalized x, y coordinates)
const projectLocations: { [key: string]: { x: number; y: number; name: string } } = {
  "solar-village-chisinau": { x: 0.45, y: 0.5, name: "Chișinău" },
  "wind-farm-balti": { x: 0.35, y: 0.8, name: "Bălți" },
  "biogas-cahul": { x: 0.25, y: 0.12, name: "Cahul" },
  "school-solar-ungheni": { x: 0.15, y: 0.55, name: "Ungheni" },
  "efficiency-hospital-tiraspol": { x: 0.75, y: 0.55, name: "Tiraspol" },
  "micro-hydro-orhei": { x: 0.5, y: 0.65, name: "Orhei" },
};

interface ProjectPinProps {
  position: [number, number, number];
  project: typeof projects[0];
  isHovered: boolean;
  onHover: (id: string | null) => void;
}

function ProjectPin({ position, project, isHovered, onHover }: ProjectPinProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const glowRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 2 + position[0]) * 0.05;
    }
    if (glowRef.current) {
      glowRef.current.scale.setScalar(1 + Math.sin(state.clock.elapsedTime * 3) * 0.1);
    }
  });

  const categoryColors: { [key: string]: string } = {
    solar: "#FACC15",
    wind: "#0EA5E9",
    biogas: "#22C55E",
    hydro: "#3B82F6",
    efficiency: "#14B8A6",
  };

  const color = categoryColors[project.category] || "#14B8A6";

  return (
    <group position={position}>
      {/* Glow effect */}
      <mesh ref={glowRef} position={[0, 0.1, 0]}>
        <sphereGeometry args={[0.15, 16, 16]} />
        <meshBasicMaterial color={color} transparent opacity={0.3} />
      </mesh>

      {/* Pin */}
      <mesh
        ref={meshRef}
        onPointerEnter={() => onHover(project.id)}
        onPointerLeave={() => onHover(null)}
      >
        <sphereGeometry args={[0.08, 16, 16]} />
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={isHovered ? 1 : 0.5}
        />
      </mesh>

      {/* Pin stem */}
      <mesh position={[0, -0.1, 0]}>
        <cylinderGeometry args={[0.02, 0.02, 0.2, 8]} />
        <meshStandardMaterial color={color} />
      </mesh>

      {/* Label on hover */}
      {isHovered && (
        <Html position={[0, 0.4, 0]} center>
          <div className="bg-card/95 backdrop-blur-md border border-border rounded-lg px-3 py-2 min-w-[150px] shadow-lg">
            <p className="text-xs font-semibold text-foreground">{project.title}</p>
            <p className="text-[10px] text-muted-foreground">{project.location}</p>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xs text-primary font-bold">
                €{(project.fundingRaised / 1000).toFixed(0)}K
              </span>
              <span className="text-[10px] text-muted-foreground">
                / €{(project.fundingGoal / 1000).toFixed(0)}K
              </span>
            </div>
          </div>
        </Html>
      )}
    </group>
  );
}

function MoldovaMap3D() {
  const [hoveredProject, setHoveredProject] = useState<string | null>(null);
  const mapRef = useRef<THREE.Group>(null);

  // Create Moldova shape
  const shape = new THREE.Shape();
  moldovaShape.forEach((point, index) => {
    const x = (point[0] - 0.5) * 4;
    const y = (point[1] - 0.5) * 5;
    if (index === 0) {
      shape.moveTo(x, y);
    } else {
      shape.lineTo(x, y);
    }
  });
  shape.closePath();

  const extrudeSettings = {
    steps: 1,
    depth: 0.15,
    bevelEnabled: true,
    bevelThickness: 0.05,
    bevelSize: 0.05,
    bevelSegments: 3,
  };

  useFrame((state) => {
    if (mapRef.current) {
      mapRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.2) * 0.1;
    }
  });

  return (
    <group ref={mapRef}>
      {/* Base map */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
        <extrudeGeometry args={[shape, extrudeSettings]} />
        <meshStandardMaterial
          color="#1a3a2a"
          metalness={0.3}
          roughness={0.7}
        />
      </mesh>

      {/* Map border glow */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.16, 0]}>
        <shapeGeometry args={[shape]} />
        <meshBasicMaterial color="#14B8A6" transparent opacity={0.1} />
      </mesh>

      {/* Grid lines */}
      {[-1.5, -0.75, 0, 0.75, 1.5].map((pos, i) => (
        <group key={i}>
          <mesh position={[pos, 0.17, 0]} rotation={[-Math.PI / 2, 0, 0]}>
            <planeGeometry args={[0.01, 5]} />
            <meshBasicMaterial color="#14B8A6" transparent opacity={0.2} />
          </mesh>
          <mesh position={[0, 0.17, pos]} rotation={[-Math.PI / 2, 0, Math.PI / 2]}>
            <planeGeometry args={[0.01, 4]} />
            <meshBasicMaterial color="#14B8A6" transparent opacity={0.2} />
          </mesh>
        </group>
      ))}

      {/* Project pins */}
      {projects.map((project) => {
        const loc = projectLocations[project.id];
        if (!loc) return null;
        const x = (loc.x - 0.5) * 4;
        const z = (loc.y - 0.5) * -5;
        return (
          <ProjectPin
            key={project.id}
            position={[x, 0.3, z]}
            project={project}
            isHovered={hoveredProject === project.id}
            onHover={setHoveredProject}
          />
        );
      })}

      {/* City labels */}
      <Text
        position={[0, 0.4, 0]}
        fontSize={0.15}
        color="#ffffff"
        anchorX="center"
        anchorY="middle"
      >
        MOLDOVA
      </Text>
    </group>
  );
}

export function MoldovaMap() {
  return (
    <div className="w-full h-full min-h-[400px] rounded-2xl overflow-hidden bg-gradient-to-b from-background to-card">
      <Canvas
        camera={{ position: [0, 5, 5], fov: 45 }}
        style={{ background: "transparent" }}
      >
        <ambientLight intensity={0.4} />
        <directionalLight position={[5, 10, 5]} intensity={1} color="#ffffff" />
        <pointLight position={[-5, 5, -5]} intensity={0.5} color="#14B8A6" />
        <pointLight position={[5, 5, 5]} intensity={0.3} color="#22C55E" />

        <MoldovaMap3D />

        <OrbitControls
          enableZoom={true}
          enablePan={false}
          minDistance={4}
          maxDistance={12}
          minPolarAngle={Math.PI / 6}
          maxPolarAngle={Math.PI / 2.5}
          autoRotate
          autoRotateSpeed={0.5}
        />
      </Canvas>
    </div>
  );
}
