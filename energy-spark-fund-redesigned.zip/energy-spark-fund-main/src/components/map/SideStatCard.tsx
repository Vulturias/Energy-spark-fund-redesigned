import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

interface SideStatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  trend?: { value: number; isPositive: boolean };
  color?: "primary" | "accent" | "solar" | "wind" | "bio" | "hydro";
  position: "left" | "right";
}

const colorClasses = {
  primary: {
    border: "border-l-primary",
    icon: "text-primary",
    glow: "shadow-[0_0_15px_hsl(174,85%,45%,0.2)]",
  },
  accent: {
    border: "border-l-accent",
    icon: "text-accent",
    glow: "shadow-[0_0_15px_hsl(142,76%,50%,0.2)]",
  },
  solar: {
    border: "border-l-energy-solar",
    icon: "text-energy-solar",
    glow: "shadow-[0_0_15px_hsl(45,95%,55%,0.2)]",
  },
  wind: {
    border: "border-l-energy-wind",
    icon: "text-energy-wind",
    glow: "shadow-[0_0_15px_hsl(199,89%,48%,0.2)]",
  },
  bio: {
    border: "border-l-energy-bio",
    icon: "text-energy-bio",
    glow: "shadow-[0_0_15px_hsl(142,76%,50%,0.2)]",
  },
  hydro: {
    border: "border-l-energy-hydro",
    icon: "text-energy-hydro",
    glow: "shadow-[0_0_15px_hsl(205,85%,50%,0.2)]",
  },
};

export function SideStatCard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  color = "primary",
  position,
}: SideStatCardProps) {
  const styles = colorClasses[color];

  return (
    <div
      className={cn(
        "relative bg-card/60 backdrop-blur-sm rounded-xl p-4 border border-border/50 transition-all duration-300 hover:bg-card/80",
        position === "left" ? "border-l-2" : "border-r-2",
        position === "left" ? styles.border : styles.border.replace("border-l", "border-r"),
        styles.glow
      )}
    >
      {/* Icon */}
      <div className="flex items-center gap-2 mb-2">
        <Icon className={cn("h-4 w-4", styles.icon)} />
        <span className="text-xs text-muted-foreground font-medium">{title}</span>
      </div>

      {/* Value */}
      <div className="flex items-baseline gap-2">
        <span className="text-2xl font-bold">{value}</span>
        {trend && (
          <span
            className={cn(
              "text-xs font-medium px-1.5 py-0.5 rounded",
              trend.isPositive
                ? "bg-accent/20 text-accent"
                : "bg-destructive/20 text-destructive"
            )}
          >
            {trend.isPositive ? "+" : ""}
            {trend.value}%
          </span>
        )}
      </div>

      {/* Subtitle */}
      {subtitle && (
        <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>
      )}
    </div>
  );
}
