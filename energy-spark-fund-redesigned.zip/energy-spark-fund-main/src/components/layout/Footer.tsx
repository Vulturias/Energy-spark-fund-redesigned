import { Link } from "react-router-dom";
import { Zap, Mail, MapPin, Phone } from "lucide-react";

const footerLinks = {
  platform: [
    { name: "Browse Projects", href: "/projects" },
    { name: "Energy Analytics", href: "/analytics" },
    { name: "Solar Calculator", href: "/calculator" },
    { name: "Start a Campaign", href: "/projects" },
  ],
  resources: [
    { name: "How It Works", href: "/#how-it-works" },
    { name: "Success Stories", href: "/projects" },
    { name: "FAQ", href: "/" },
    { name: "Blog", href: "/" },
  ],
  legal: [
    { name: "Terms of Service", href: "/" },
    { name: "Privacy Policy", href: "/" },
    { name: "Cookie Policy", href: "/" },
  ],
};

export function Footer() {
  return (
    <footer className="border-t border-border/50 bg-card/30">
      <div className="container py-12 md:py-16">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-primary shadow-glow">
                <Zap className="h-5 w-5 text-background" />
              </div>
              <span className="text-xl font-bold tracking-tight text-gradient">BUCEFALUS</span>
            </Link>
            <p className="text-sm text-muted-foreground mb-4 max-w-xs">
              Empowering Moldova's energy transition through community-driven crowdfunding for renewable energy projects.
            </p>
            <div className="flex flex-col gap-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                <span>Chișinău, Moldova</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                <span>contact@bucefalus.md</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <span>+373 22 123 456</span>
              </div>
            </div>
          </div>

          {/* Platform Links */}
          <div>
            <h3 className="font-semibold mb-4">Platform</h3>
            <ul className="space-y-2">
              {footerLinks.platform.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources Links */}
          <div>
            <h3 className="font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
              {footerLinks.resources.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal Links */}
          <div>
            <h3 className="font-semibold mb-4">Legal</h3>
            <ul className="space-y-2">
              {footerLinks.legal.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} BUCEFALUS. All rights reserved.
          </p>
          <p className="text-sm text-muted-foreground">
            Powering Moldova's sustainable future 🇲🇩
          </p>
        </div>
      </div>
    </footer>
  );
}
