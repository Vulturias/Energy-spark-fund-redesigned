import { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

interface InfoCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: LucideIcon;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  color?: "primary" | "accent" | "solar" | "wind" | "bio";
  className?: string;
  children?: ReactNode;
}

const colorStyles = {
  primary: "border-primary/30 shadow-glow",
  accent: "border-accent/30 shadow-glow-accent",
  solar: "border-energy-solar/30 shadow-glow-solar",
  wind: "border-energy-wind/30",
  bio: "border-energy-bio/30",
};

const iconColors = {
  primary: "text-primary",
  accent: "text-accent",
  solar: "text-energy-solar",
  wind: "text-energy-wind",
  bio: "text-energy-bio",
};

export function InfoCard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  color = "primary",
  className,
  children,
}: InfoCardProps) {
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-2xl bg-card/80 backdrop-blur-sm border p-5 transition-all duration-300 hover:scale-[1.02]",
        colorStyles[color],
        className
      )}
    >
      {/* Background glow effect */}
      <div
        className={cn(
          "absolute -top-12 -right-12 h-32 w-32 rounded-full opacity-20 blur-3xl",
          color === "primary" && "bg-primary",
          color === "accent" && "bg-accent",
          color === "solar" && "bg-energy-solar",
          color === "wind" && "bg-energy-wind",
          color === "bio" && "bg-energy-bio"
        )}
      />

      <div className="relative">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            {Icon && (
              <Icon className={cn("h-5 w-5", iconColors[color])} />
            )}
            <span className="text-sm font-medium text-muted-foreground">
              {title}
            </span>
          </div>
          {trend && (
            <span
              className={cn(
                "text-xs font-semibold px-2 py-0.5 rounded-full",
                trend.isPositive
                  ? "bg-accent/20 text-accent"
                  : "bg-destructive/20 text-destructive"
              )}
            >
              {trend.isPositive ? "+" : ""}
              {trend.value}%
            </span>
          )}
        </div>

        <div className="text-3xl font-bold tracking-tight mb-1">{value}</div>

        {subtitle && (
          <p className="text-sm text-muted-foreground">{subtitle}</p>
        )}

        {children && <div className="mt-4">{children}</div>}
      </div>
    </div>
  );
}
