import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, ComposedChart, Bar, Line } from "recharts";
import { electricityMonthly2024 } from "@/data/moldovaEnergyData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Zap, AlertTriangle } from "lucide-react";

export const ElectricityProductionChart = () => {
  return (
    <Card className="border-border/30 bg-card/80 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-energy-solar" />
            <CardTitle className="text-lg font-semibold">Electricity 2024</CardTitle>
          </div>
          <Badge variant="outline" className="text-xs border-destructive/50 text-destructive">
            <AlertTriangle className="h-3 w-3 mr-1" />
            Nov: 9x Import Spike
          </Badge>
        </div>
        <p className="text-xs text-muted-foreground">Production vs Import in MWh</p>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={electricityMonthly2024}>
              <defs>
                <linearGradient id="productionGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="importGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--destructive))" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(var(--destructive))" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
              <XAxis 
                dataKey="month" 
                stroke="hsl(var(--muted-foreground))" 
                fontSize={11}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))" 
                fontSize={11}
                tickFormatter={(v) => `${(v / 1000).toFixed(0)}K`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "8px",
                  fontSize: "12px",
                }}
                formatter={(value: number, name: string) => [
                  `${(value / 1000).toFixed(0)}K MWh`,
                  name === "production" ? "Production" : "Import"
                ]}
              />
              <Legend 
                wrapperStyle={{ fontSize: "11px" }}
                formatter={(value) => value === "production" ? "Production" : "Import"}
              />
              <Area 
                type="monotone" 
                dataKey="production" 
                stroke="hsl(var(--primary))" 
                fill="url(#productionGradient)"
                strokeWidth={2}
              />
              <Area 
                type="monotone" 
                dataKey="import" 
                stroke="hsl(var(--destructive))" 
                fill="url(#importGradient)"
                strokeWidth={2}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
        
        {/* Key metrics */}
        <div className="grid grid-cols-3 gap-3 mt-4">
          <div className="p-3 rounded-lg bg-primary/5 border border-primary/20 text-center">
            <p className="text-lg font-bold text-primary">1.2 GWh</p>
            <p className="text-xs text-muted-foreground">Production 2024</p>
          </div>
          <div className="p-3 rounded-lg bg-destructive/5 border border-destructive/20 text-center">
            <p className="text-lg font-bold text-destructive">275K</p>
            <p className="text-xs text-muted-foreground">Nov Import MWh</p>
          </div>
          <div className="p-3 rounded-lg bg-accent/5 border border-accent/20 text-center">
            <p className="text-lg font-bold text-accent">10x</p>
            <p className="text-xs text-muted-foreground">Seasonal Variance</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
