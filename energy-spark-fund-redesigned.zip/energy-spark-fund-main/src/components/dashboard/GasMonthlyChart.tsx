import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, ReferenceLine, Line, ComposedChart, Area } from "recharts";
import { gasMonthly2024, gasYearlyImports, seasonalGasPattern } from "@/data/moldovaEnergyData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Flame, TrendingDown, AlertTriangle } from "lucide-react";

const getSeasonColor = (month: string): string => {
  const winterMonths = ["Dec", "Jan", "Feb"];
  const springMonths = ["Mar", "Apr", "May"];
  const summerMonths = ["Jun", "Jul", "Aug"];
  if (winterMonths.includes(month)) return "hsl(0, 70%, 50%)";
  if (springMonths.includes(month)) return "hsl(25, 95%, 53%)";
  if (summerMonths.includes(month)) return "hsl(45, 93%, 47%)";
  return "hsl(25, 80%, 50%)";
};

export const GasMonthlyChart = () => {
  return (
    <Card className="border-border/30 bg-card/80 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Flame className="h-5 w-5 text-energy-gas" />
            <CardTitle className="text-lg font-semibold">Natural Gas 2024</CardTitle>
          </div>
          <Badge variant="outline" className="text-xs border-destructive/50 text-destructive">
            <AlertTriangle className="h-3 w-3 mr-1" />
            100% Import
          </Badge>
        </div>
        <p className="text-xs text-muted-foreground">Monthly imports in thousand m³ • Winter 6x higher than summer</p>
      </CardHeader>
      <CardContent>
        <div className="h-[280px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={gasMonthly2024} barCategoryGap="15%">
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
              <XAxis 
                dataKey="month" 
                stroke="hsl(var(--muted-foreground))" 
                fontSize={11}
                tickLine={false}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))" 
                fontSize={11}
                tickLine={false}
                tickFormatter={(v) => `${(v / 1000).toFixed(0)}K`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "8px",
                  fontSize: "12px",
                }}
                formatter={(value: number) => [`${value.toLocaleString()} thousand m³`, "Import"]}
              />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {gasMonthly2024.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={getSeasonColor(entry.month)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        
        {/* Season Legend */}
        <div className="flex items-center justify-center gap-6 mt-4 text-xs">
          <div className="flex items-center gap-1.5">
            <div className="h-3 w-3 rounded-full" style={{ backgroundColor: "hsl(0, 70%, 50%)" }} />
            <span className="text-muted-foreground">Winter (130-165K)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="h-3 w-3 rounded-full" style={{ backgroundColor: "hsl(45, 93%, 47%)" }} />
            <span className="text-muted-foreground">Summer (20-30K)</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export const GasYearlyTrendChart = () => {
  return (
    <Card className="border-border/30 bg-card/80 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Gas Import Trend 2015-2024</CardTitle>
          <Badge variant="outline" className="text-xs border-primary/50 text-primary">
            <TrendingDown className="h-3 w-3 mr-1" />
            -40% from 2022
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[280px]">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={gasYearlyImports}>
              <defs>
                <linearGradient id="gasGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(210, 40%, 50%)" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="hsl(210, 40%, 50%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
              <XAxis 
                dataKey="year" 
                stroke="hsl(var(--muted-foreground))" 
                fontSize={11}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))" 
                fontSize={11}
                tickFormatter={(v) => `${(v / 1000).toFixed(0)}K`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "8px",
                }}
                formatter={(value: number) => [`${(value / 1000).toFixed(0)}K thousand m³`, "Import"]}
              />
              <Area 
                type="monotone" 
                dataKey="import" 
                stroke="hsl(210, 40%, 50%)" 
                fill="url(#gasGradient)"
                strokeWidth={2}
              />
              {/* 2022 peak marker */}
              <ReferenceLine 
                x={2022} 
                stroke="hsl(var(--destructive))" 
                strokeDasharray="5 5"
                label={{ value: "2022 Peak", position: "top", fontSize: 10, fill: "hsl(var(--destructive))" }}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};
