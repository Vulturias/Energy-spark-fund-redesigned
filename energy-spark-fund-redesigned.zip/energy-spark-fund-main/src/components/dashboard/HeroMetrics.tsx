import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  AlertTriangle, 
  Flame, 
  Droplets, 
  Zap, 
  Factory,
  TrendingDown,
  TrendingUp,
  ArrowDown,
  CircleAlert
} from "lucide-react";
import { criticalIndicators, energyMix2023 } from "@/data/moldovaEnergyData";

// Mini donut chart component
const MiniDonut = ({ value, color, size = 60 }: { value: number; color: string; size?: number }) => {
  const radius = (size - 8) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (value / 100) * circumference;
  
  return (
    <svg width={size} height={size} className="transform -rotate-90">
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        stroke="currentColor"
        strokeWidth="4"
        className="text-muted/20"
      />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        stroke={color}
        strokeWidth="4"
        strokeLinecap="round"
        strokeDasharray={circumference}
        strokeDashoffset={strokeDashoffset}
        className="transition-all duration-1000"
      />
    </svg>
  );
};

export const HeroMetrics = () => {
  const topMetrics = [
    {
      label: "Import Dependency",
      value: criticalIndicators.overallImportDependency,
      suffix: "%",
      sublabel: "of energy imported",
      icon: AlertTriangle,
      color: "text-red-400",
      bgColor: "bg-red-500/10",
      trend: null,
      severity: "critical",
      glow: "shadow-glow-accent"
    },
    {
      label: "Natural Gas",
      value: criticalIndicators.domesticGasProduction,
      suffix: "%",
      sublabel: "domestic production",
      icon: Flame,
      color: "text-orange-400",
      bgColor: "bg-orange-500/10",
      trend: { value: -40, label: "vs 2022" },
      severity: "critical",
      glow: "glow-solar"
    },
    {
      label: "Petroleum",
      value: criticalIndicators.petroleumImportDependency,
      suffix: "%",
      sublabel: "import dependency",
      icon: Droplets,
      color: "text-amber-400",
      bgColor: "bg-amber-500/10",
      trend: { value: 5, label: "vs 2022" },
      severity: "high",
      glow: ""
    },
    {
      label: "Electricity",
      value: 40,
      suffix: "%",
      sublabel: "from imports",
      icon: Zap,
      color: "text-cyan-400",
      bgColor: "bg-cyan-500/10",
      trend: { value: 9, label: "Nov spike" },
      severity: "warning",
      glow: "shadow-glow"
    },
    {
      label: "Coal",
      value: 100,
      suffix: "%",
      sublabel: "import dependency",
      icon: Factory,
      color: "text-slate-400",
      bgColor: "bg-slate-500/10",
      trend: { value: -42, label: "vs 2022" },
      severity: "critical",
      glow: ""
    },
  ];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-2">
        <div>
          <Badge className="mb-2 bg-red-500/20 text-red-400 border-red-500/30 backdrop-blur-sm">
            <CircleAlert className="mr-1.5 h-3.5 w-3.5" />
            Energy Security Crisis
          </Badge>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight">
            Moldova Energy Monitor
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Real-time statistics • Excludes Transnistria
          </p>
        </div>
        <div className="text-right text-xs text-muted-foreground">
          <p className="font-mono-metric">Updated: Jan 2025</p>
          <p className="text-[10px]">Data: 2015-2024</p>
        </div>
      </div>

      {/* Main Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2 md:gap-3">
        {topMetrics.map((metric) => {
          const Icon = metric.icon;
          const isNegativeTrend = metric.trend && metric.trend.value < 0;
          
          return (
            <div 
              key={metric.label} 
              className={`glass relative overflow-hidden rounded-md p-3 transition-all duration-300 hover:-translate-y-0.5 ${metric.glow} ${
                metric.severity === 'critical' 
                  ? 'ring-1 ring-red-500/20' 
                  : metric.severity === 'high'
                  ? 'ring-1 ring-orange-500/20'
                  : ''
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className={`h-8 w-8 rounded-lg ${metric.bgColor} flex items-center justify-center backdrop-blur-sm`}>
                  <Icon className={`h-4 w-4 ${metric.color}`} />
                </div>
                {metric.severity === 'critical' && (
                  <Badge variant="destructive" className="text-[9px] px-1 py-0 h-4 bg-red-500/20 text-red-400 border-red-500/30">
                    ALERT
                  </Badge>
                )}
              </div>
              
              <div className="space-y-0.5">
                <div className="flex items-baseline gap-0.5">
                  <span className={`text-2xl md:text-3xl font-extrabold font-mono-metric ${metric.color}`}>
                    {metric.value}
                  </span>
                  <span className="text-sm text-muted-foreground">{metric.suffix}</span>
                </div>
                <p className="text-xs font-semibold">{metric.label}</p>
                <p className="text-[10px] text-muted-foreground">{metric.sublabel}</p>
              </div>

              {metric.trend && (
                <div className={`mt-2 flex items-center gap-0.5 text-[10px] ${
                  isNegativeTrend ? 'text-emerald-400' : 'text-red-400'
                }`}>
                  {isNegativeTrend ? (
                    <TrendingDown className="h-3 w-3" />
                  ) : (
                    <TrendingUp className="h-3 w-3" />
                  )}
                  <span className="font-semibold font-mono-metric">
                    {isNegativeTrend ? '' : '+'}{metric.trend.value}%
                  </span>
                  <span className="text-muted-foreground">{metric.trend.label}</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Energy Mix & Dependency Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        {/* Energy Mix Breakdown */}
        <div className="glass rounded-md p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-sm">Energy Mix 2023</h3>
            <span className="text-[10px] text-muted-foreground font-mono-metric">Total: 110,361 TJ</span>
          </div>
          <div className="space-y-2">
            {energyMix2023.map((source) => (
              <div key={source.name} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5">
                    <div 
                      className="h-2 w-2 rounded-full" 
                      style={{ backgroundColor: source.color, boxShadow: `0 0 8px ${source.color}` }}
                    />
                    <span className="text-[11px]">{source.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground text-[10px] font-mono-metric">{source.value.toLocaleString()} TJ</span>
                    <span className="font-semibold w-10 text-right font-mono-metric">{source.percentage}%</span>
                  </div>
                </div>
                <Progress 
                  value={source.percentage} 
                  className="h-1.5"
                  style={{ 
                    '--progress-background': source.color 
                  } as React.CSSProperties}
                />
              </div>
            ))}
          </div>
        </div>

        {/* Import Dependency by Source */}
        <div className="glass rounded-md p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-sm">Import Dependency</h3>
            <Badge variant="outline" className="text-red-400 border-red-500/30 text-[9px] h-5">
              Single-source risk
            </Badge>
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            {/* Gas */}
            <div className="flex items-center gap-2">
              <div className="relative">
                <MiniDonut value={100} color="hsl(0 84% 60%)" size={50} />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-[10px] font-bold font-mono-metric">100%</span>
                </div>
              </div>
              <div>
                <p className="font-medium text-xs">Gas</p>
                <p className="text-[10px] text-red-400">Russia</p>
              </div>
            </div>

            {/* Oil */}
            <div className="flex items-center gap-2">
              <div className="relative">
                <MiniDonut value={99.7} color="hsl(38 92% 50%)" size={50} />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-[10px] font-bold font-mono-metric">99.7%</span>
                </div>
              </div>
              <div>
                <p className="font-medium text-xs">Oil</p>
                <p className="text-[10px] text-muted-foreground">Multi</p>
              </div>
            </div>

            {/* Coal */}
            <div className="flex items-center gap-2">
              <div className="relative">
                <MiniDonut value={100} color="hsl(0 0% 35%)" size={50} />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-[10px] font-bold font-mono-metric">100%</span>
                </div>
              </div>
              <div>
                <p className="font-medium text-xs">Coal</p>
                <p className="text-[10px] text-emerald-400 flex items-center gap-0.5">
                  <ArrowDown className="h-2.5 w-2.5" />-42%
                </p>
              </div>
            </div>

            {/* Electricity */}
            <div className="flex items-center gap-2">
              <div className="relative">
                <MiniDonut value={40} color="hsl(189 94% 55%)" size={50} />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-[10px] font-bold font-mono-metric">~40%</span>
                </div>
              </div>
              <div>
                <p className="font-medium text-xs">Power</p>
                <p className="text-[10px] text-red-400 flex items-center gap-0.5">
                  <AlertTriangle className="h-2.5 w-2.5" />9x spike
                </p>
              </div>
            </div>
          </div>

          {/* Self-sufficiency indicator */}
          <div className="mt-3 pt-3 border-t border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-medium">Self-Sufficiency</p>
                <p className="text-[10px] text-muted-foreground">Domestic production</p>
              </div>
              <div className="text-right">
                <p className="text-xl font-bold text-emerald-400 font-mono-metric">22.2%</p>
                <p className="text-[10px] text-muted-foreground font-mono-metric">24,518 TJ</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
