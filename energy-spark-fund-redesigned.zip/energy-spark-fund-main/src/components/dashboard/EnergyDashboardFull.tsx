import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { CriticalMetrics } from "./CriticalMetrics";
import { EnergyMixDonut } from "./EnergyMixDonut";
import { SectorConsumptionChart } from "./SectorConsumptionChart";
import { GasMonthlyChart, GasYearlyTrendChart } from "./GasMonthlyChart";
import { ElectricityProductionChart } from "./ElectricityChart";
import { ImportDependencyBars } from "./ImportDependencyBars";
import { EnergyBalanceTrend } from "./EnergyBalanceTrend";
import { Comparison2022vs2024 } from "./Comparison2022vs2024";
import { CrisisAlerts } from "./CrisisAlerts";
import { BarChart3, Flame, Zap, Map, AlertTriangle } from "lucide-react";

export const EnergyDashboardFull = () => {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <Badge variant="outline" className="mb-3 border-destructive/30 text-destructive">
          <AlertTriangle className="mr-1.5 h-3 w-3" />
          77.8% Import Dependent
        </Badge>
        <h2 className="text-2xl md:text-3xl font-bold tracking-tight">
          Moldova Energy Dashboard
        </h2>
        <p className="text-sm text-muted-foreground mt-2 max-w-xl mx-auto">
          Real-time data from National Bureau of Statistics • Excludes Transnistria
        </p>
      </div>

      {/* Critical Metrics */}
      <CriticalMetrics />

      {/* Tabbed Dashboards */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full max-w-2xl mx-auto grid-cols-4 h-12">
          <TabsTrigger value="overview" className="text-xs md:text-sm">
            <BarChart3 className="h-4 w-4 mr-1.5 hidden sm:inline" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="gas" className="text-xs md:text-sm">
            <Flame className="h-4 w-4 mr-1.5 hidden sm:inline" />
            Natural Gas
          </TabsTrigger>
          <TabsTrigger value="electricity" className="text-xs md:text-sm">
            <Zap className="h-4 w-4 mr-1.5 hidden sm:inline" />
            Electricity
          </TabsTrigger>
          <TabsTrigger value="dependency" className="text-xs md:text-sm">
            <Map className="h-4 w-4 mr-1.5 hidden sm:inline" />
            Dependency
          </TabsTrigger>
        </TabsList>

        {/* OVERVIEW TAB */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-3">
            <EnergyMixDonut />
            <SectorConsumptionChart />
            <CrisisAlerts />
          </div>
          <EnergyBalanceTrend />
        </TabsContent>

        {/* GAS TAB */}
        <TabsContent value="gas" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <GasMonthlyChart />
            <GasYearlyTrendChart />
          </div>
          
          {/* Gas insights */}
          <div className="grid gap-4 md:grid-cols-3">
            <div className="rounded-xl bg-energy-gas/5 border border-energy-gas/20 p-5">
              <p className="text-3xl font-bold text-energy-gas mb-1">0%</p>
              <p className="text-sm text-muted-foreground">Domestic Production</p>
              <p className="text-xs text-muted-foreground/60 mt-1">100% imported from Russia</p>
            </div>
            <div className="rounded-xl bg-destructive/5 border border-destructive/20 p-5">
              <p className="text-3xl font-bold text-destructive mb-1">-40%</p>
              <p className="text-sm text-muted-foreground">Drop 2022→2024</p>
              <p className="text-xs text-muted-foreground/60 mt-1">From 1.65M to 965K thousand m³</p>
            </div>
            <div className="rounded-xl bg-orange-500/5 border border-orange-500/20 p-5">
              <p className="text-3xl font-bold text-orange-500 mb-1">6x</p>
              <p className="text-sm text-muted-foreground">Seasonal Variation</p>
              <p className="text-xs text-muted-foreground/60 mt-1">Winter 165K vs Summer 25K m³</p>
            </div>
          </div>
        </TabsContent>

        {/* ELECTRICITY TAB */}
        <TabsContent value="electricity" className="space-y-6">
          <ElectricityProductionChart />
          
          {/* Electricity insights */}
          <div className="grid gap-4 md:grid-cols-4">
            <div className="rounded-xl bg-primary/5 border border-primary/20 p-5">
              <p className="text-2xl font-bold text-primary mb-1">1.2 GWh</p>
              <p className="text-sm text-muted-foreground">2024 Production</p>
            </div>
            <div className="rounded-xl bg-destructive/5 border border-destructive/20 p-5">
              <p className="text-2xl font-bold text-destructive mb-1">274,931</p>
              <p className="text-sm text-muted-foreground">Nov Import MWh</p>
              <p className="text-xs text-muted-foreground/60 mt-1">9x normal levels</p>
            </div>
            <div className="rounded-xl bg-accent/5 border border-accent/20 p-5">
              <p className="text-2xl font-bold text-accent mb-1">40-45%</p>
              <p className="text-sm text-muted-foreground">Residential Share</p>
            </div>
            <div className="rounded-xl bg-orange-500/5 border border-orange-500/20 p-5">
              <p className="text-2xl font-bold text-orange-500 mb-1">10x</p>
              <p className="text-sm text-muted-foreground">Winter vs Summer</p>
            </div>
          </div>
        </TabsContent>

        {/* DEPENDENCY TAB */}
        <TabsContent value="dependency" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <ImportDependencyBars />
            <Comparison2022vs2024 />
          </div>
          
          {/* Key message */}
          <div className="rounded-2xl bg-gradient-to-r from-destructive/10 via-destructive/5 to-transparent border border-destructive/20 p-6">
            <div className="flex items-start gap-4">
              <AlertTriangle className="h-8 w-8 text-destructive flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-lg mb-2">Critical Energy Vulnerability</h3>
                <p className="text-muted-foreground text-sm">
                  Moldova has essentially <strong>zero domestic fossil fuel production</strong>. 
                  Natural gas (100% imported from Russia), coal (100% imported), and petroleum (99.7% imported) 
                  leave the country extremely vulnerable to supply disruptions and price shocks. 
                  The 2022 energy crisis demonstrated this risk clearly.
                </p>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Footer */}
      <div className="text-center pt-4 border-t border-border/30">
        <p className="text-xs text-muted-foreground">
          Data: National Bureau of Statistics of Moldova (statistica.gov.md) • Last updated: January 2025
        </p>
      </div>
    </div>
  );
};
