import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { energyMix2023 } from "@/data/moldovaEnergyData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const EnergyMixDonut = () => {
  return (
    <Card className="border-border/30 bg-card/80 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold">
          Energy Mix 2023
        </CardTitle>
        <p className="text-xs text-muted-foreground">Total: 110,361 TJ</p>
      </CardHeader>
      <CardContent>
        <div className="h-[280px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={energyMix2023}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={2}
                dataKey="value"
              >
                {energyMix2023.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "8px",
                  fontSize: "12px",
                }}
                formatter={(value: number, name: string) => [
                  `${value.toLocaleString()} TJ (${energyMix2023.find(e => e.name === name)?.percentage}%)`,
                  name,
                ]}
              />
              <Legend
                layout="vertical"
                verticalAlign="middle"
                align="right"
                wrapperStyle={{ fontSize: "11px" }}
                formatter={(value: string) => {
                  const item = energyMix2023.find(e => e.name === value);
                  return `${value} ${item?.percentage}%`;
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};
