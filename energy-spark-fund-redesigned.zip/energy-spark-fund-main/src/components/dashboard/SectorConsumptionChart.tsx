import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { sectorConsumption2023 } from "@/data/moldovaEnergyData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Home, Car, Building2, Factory, Tractor, MoreHorizontal } from "lucide-react";

const sectorIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  Residential: Home,
  Transport: Car,
  Services: Building2,
  Industry: Factory,
  Agriculture: Tractor,
  Other: MoreHorizontal,
};

export const SectorConsumptionChart = () => {
  return (
    <Card className="border-border/30 bg-card/80 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold">
          Consumption by Sector
        </CardTitle>
        <p className="text-xs text-muted-foreground">Total: 103,453 TJ</p>
      </CardHeader>
      <CardContent>
        <div className="h-[200px] mb-4">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={sectorConsumption2023}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={2}
                dataKey="value"
              >
                {sectorConsumption2023.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "8px",
                  fontSize: "12px",
                }}
                formatter={(value: number, name: string) => [
                  `${value.toLocaleString()} TJ`,
                  name,
                ]}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {sectorConsumption2023.slice(0, 4).map((sector) => {
            const Icon = sectorIcons[sector.sector] || MoreHorizontal;
            return (
              <div key={sector.sector} className="flex items-center gap-2 p-2 rounded-lg bg-background/50">
                <div 
                  className="h-8 w-8 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: `${sector.color}20` }}
                >
                  <Icon className="h-4 w-4" style={{ color: sector.color }} />
                </div>
                <div>
                  <p className="text-xs font-medium">{sector.sector}</p>
                  <p className="text-xs text-muted-foreground">{sector.percentage}%</p>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};
