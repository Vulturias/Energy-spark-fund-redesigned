import { criticalIndicators, annual2024 } from "@/data/moldovaEnergyData";
import { Flame, Droplets, Factory, AlertTriangle, Leaf, Zap } from "lucide-react";

interface MetricCardProps {
  value: string;
  label: string;
  sublabel?: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  bgColor: string;
  alert?: boolean;
}

const MetricCard = ({ value, label, sublabel, icon: Icon, color, bgColor, alert }: MetricCardProps) => (
  <div className={`relative rounded-2xl border ${alert ? 'border-destructive/50' : 'border-border/30'} bg-card/80 backdrop-blur-sm p-5 transition-all duration-300 hover:border-primary/40`}>
    {alert && (
      <div className="absolute top-3 right-3">
        <AlertTriangle className="h-4 w-4 text-destructive animate-pulse" />
      </div>
    )}
    <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${bgColor} mb-4`}>
      <Icon className={`h-6 w-6 ${color}`} />
    </div>
    <p className="text-4xl md:text-5xl font-bold tracking-tight text-foreground mb-1">
      {value}
    </p>
    <p className="text-sm text-muted-foreground">{label}</p>
    {sublabel && <p className="text-xs text-muted-foreground/60 mt-1">{sublabel}</p>}
  </div>
);

export const CriticalMetrics = () => {
  const metrics: MetricCardProps[] = [
    {
      value: `${criticalIndicators.overallImportDependency}%`,
      label: "Import Dependency",
      sublabel: "Energy imported from abroad",
      icon: Factory,
      color: "text-destructive",
      bgColor: "bg-destructive/10",
      alert: true,
    },
    {
      value: `${criticalIndicators.gasImportDependency}%`,
      label: "Gas Import",
      sublabel: "0% domestic production",
      icon: Flame,
      color: "text-energy-gas",
      bgColor: "bg-energy-gas/10",
      alert: true,
    },
    {
      value: `${criticalIndicators.petroleumImportDependency}%`,
      label: "Oil Import",
      sublabel: "~3,000t domestic only",
      icon: Droplets,
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
      alert: true,
    },
    {
      value: `${criticalIndicators.renewableShare}%`,
      label: "Renewable Share",
      sublabel: "Mostly traditional biomass",
      icon: Leaf,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      value: `${(annual2024.gasImport / 1000).toFixed(0)}K`,
      label: "Gas Import 2024",
      sublabel: "thousand m³ (-40% vs 2022)",
      icon: Flame,
      color: "text-energy-gas",
      bgColor: "bg-energy-gas/10",
    },
    {
      value: `${(annual2024.electricityProduction / 1000).toFixed(1)}`,
      label: "Electricity GWh",
      sublabel: "2024 production",
      icon: Zap,
      color: "text-energy-solar",
      bgColor: "bg-energy-solar/10",
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {metrics.map((metric) => (
        <MetricCard key={metric.label} {...metric} />
      ))}
    </div>
  );
};
