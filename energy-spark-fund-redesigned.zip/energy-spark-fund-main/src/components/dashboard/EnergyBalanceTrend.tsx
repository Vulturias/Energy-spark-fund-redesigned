import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { energyBalanceYearly, trendChanges } from "@/data/moldovaEnergyData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";

const COLORS = {
  petroleum: "hsl(25, 95%, 53%)",
  gas: "hsl(210, 40%, 50%)",
  bio: "hsl(142, 71%, 45%)",
  electricity: "hsl(199, 89%, 48%)",
  coal: "hsl(0, 0%, 40%)",
};

interface TrendBadgeProps {
  label: string;
  change: number;
  color: string;
}

const TrendBadge = ({ label, change, color }: TrendBadgeProps) => {
  const Icon = change > 0 ? TrendingUp : change < 0 ? TrendingDown : Minus;
  const textColor = change > 0 ? "text-primary" : change < 0 ? "text-destructive" : "text-muted-foreground";
  
  return (
    <div className="flex items-center gap-1.5 p-2 rounded-lg bg-background/50">
      <div className="h-3 w-3 rounded-full" style={{ backgroundColor: color }} />
      <span className="text-xs font-medium">{label}</span>
      <Icon className={`h-3 w-3 ${textColor}`} />
      <span className={`text-xs font-semibold ${textColor}`}>
        {change > 0 ? "+" : ""}{change}%
      </span>
    </div>
  );
};

export const EnergyBalanceTrend = () => {
  return (
    <Card className="border-border/30 bg-card/80 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Energy Mix Evolution 2010-2023</CardTitle>
          <Badge variant="outline" className="text-xs">Terajoules</Badge>
        </div>
        <p className="text-xs text-muted-foreground">Stacked area showing shift from gas to petroleum</p>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={energyBalanceYearly}>
              <defs>
                {Object.entries(COLORS).map(([key, color]) => (
                  <linearGradient key={key} id={`${key}Gradient`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={color} stopOpacity={0.6} />
                    <stop offset="95%" stopColor={color} stopOpacity={0.1} />
                  </linearGradient>
                ))}
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
              <XAxis dataKey="year" stroke="hsl(var(--muted-foreground))" fontSize={11} />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} tickFormatter={(v) => `${(v / 1000).toFixed(0)}K`} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "8px",
                  fontSize: "12px",
                }}
                formatter={(value: number, name: string) => [
                  `${value.toLocaleString()} TJ`,
                  name.charAt(0).toUpperCase() + name.slice(1)
                ]}
              />
              <Legend 
                wrapperStyle={{ fontSize: "11px" }}
                formatter={(value) => value.charAt(0).toUpperCase() + value.slice(1)}
              />
              <Area type="monotone" dataKey="petroleum" stackId="1" stroke={COLORS.petroleum} fill={`url(#petroleumGradient)`} />
              <Area type="monotone" dataKey="gas" stackId="1" stroke={COLORS.gas} fill={`url(#gasGradient)`} />
              <Area type="monotone" dataKey="bio" stackId="1" stroke={COLORS.bio} fill={`url(#bioGradient)`} />
              <Area type="monotone" dataKey="electricity" stackId="1" stroke={COLORS.electricity} fill={`url(#electricityGradient)`} />
              <Area type="monotone" dataKey="coal" stackId="1" stroke={COLORS.coal} fill={`url(#coalGradient)`} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        
        {/* Trend badges */}
        <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
          <TrendBadge label="Oil" change={trendChanges.petroleum.change} color={COLORS.petroleum} />
          <TrendBadge label="Gas" change={trendChanges.gas.change} color={COLORS.gas} />
          <TrendBadge label="Coal" change={trendChanges.coal.change} color={COLORS.coal} />
          <TrendBadge label="Bio" change={trendChanges.biofuels.change} color={COLORS.bio} />
          <TrendBadge label="Elec" change={trendChanges.electricity.change} color={COLORS.electricity} />
        </div>
      </CardContent>
    </Card>
  );
};
