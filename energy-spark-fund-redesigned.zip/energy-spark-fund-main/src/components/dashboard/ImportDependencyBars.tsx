import { criticalIndicators, importSources } from "@/data/moldovaEnergyData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Flame, Droplets, Zap } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface DependencyBarProps {
  label: string;
  value: number;
  source: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  alert?: boolean;
}

const DependencyBar = ({ label, value, source, icon: Icon, color, alert }: DependencyBarProps) => (
  <div className="space-y-2">
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2">
        <Icon className={`h-4 w-4 ${color}`} />
        <span className="text-sm font-medium">{label}</span>
        {alert && <AlertTriangle className="h-3 w-3 text-destructive animate-pulse" />}
      </div>
      <div className="flex items-center gap-2">
        <span className="text-xs text-muted-foreground">{source}</span>
        <Badge variant={value === 100 ? "destructive" : "secondary"} className="text-xs">
          {value}%
        </Badge>
      </div>
    </div>
    <div className="relative h-4 rounded-full bg-muted/30 overflow-hidden">
      <div 
        className={`absolute inset-y-0 left-0 rounded-full transition-all duration-500 ${
          value === 100 ? 'bg-gradient-to-r from-destructive to-destructive/70' : 
          value > 75 ? 'bg-gradient-to-r from-orange-500 to-orange-500/70' :
          'bg-gradient-to-r from-primary to-primary/70'
        }`}
        style={{ width: `${value}%` }}
      />
    </div>
  </div>
);

export const ImportDependencyBars = () => {
  return (
    <Card className="border-border/30 bg-card/80 backdrop-blur-sm">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Import Dependency by Source</CardTitle>
          <Badge variant="outline" className="text-xs">
            Self-sufficiency: {criticalIndicators.selfSufficiency}%
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-5">
        <DependencyBar
          label="Natural Gas"
          value={criticalIndicators.gasImportDependency}
          source="Russia 100%"
          icon={Flame}
          color="text-energy-gas"
          alert
        />
        <DependencyBar
          label="Petroleum"
          value={criticalIndicators.petroleumImportDependency}
          source="Romania, Ukraine"
          icon={Droplets}
          color="text-orange-500"
          alert
        />
        <DependencyBar
          label="Coal"
          value={criticalIndicators.coalImportDependency}
          source="Various"
          icon={({ className }) => (
            <svg className={className} viewBox="0 0 24 24" fill="currentColor">
              <path d="M18 10h-4V6h-4v4H6v4h4v4h4v-4h4v-4z" />
            </svg>
          )}
          color="text-gray-500"
        />
        <DependencyBar
          label="Electricity (Variable)"
          value={40}
          source="Ukraine, Romania"
          icon={Zap}
          color="text-energy-solar"
        />
        
        {/* Overall dependency */}
        <div className="pt-4 border-t border-border/30">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold">Overall Energy Import</span>
            <span className="text-2xl font-bold text-destructive">{criticalIndicators.overallImportDependency}%</span>
          </div>
          <Progress value={criticalIndicators.overallImportDependency} className="h-3" />
        </div>
      </CardContent>
    </Card>
  );
};
