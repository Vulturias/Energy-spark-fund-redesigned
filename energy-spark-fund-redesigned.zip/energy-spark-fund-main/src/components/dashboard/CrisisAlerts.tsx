import { crisisEvents } from "@/data/moldovaEnergyData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Zap, Flame, AlertCircle } from "lucide-react";

const getSeverityColor = (severity: string) => {
  switch (severity) {
    case "critical": return "bg-destructive/10 border-destructive/30 text-destructive";
    case "high": return "bg-orange-500/10 border-orange-500/30 text-orange-500";
    default: return "bg-yellow-500/10 border-yellow-500/30 text-yellow-500";
  }
};

const getIcon = (type: string) => {
  switch (type) {
    case "electricity": return Zap;
    case "gas": return Flame;
    default: return AlertCircle;
  }
};

export const CrisisAlerts = () => {
  return (
    <Card className="border-destructive/30 bg-card/80 backdrop-blur-sm">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-destructive" />
          <CardTitle className="text-lg font-semibold">Critical Alerts 2024</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {crisisEvents.map((event, index) => {
          const Icon = getIcon(event.type);
          return (
            <div
              key={index}
              className={`flex items-start gap-3 p-3 rounded-lg border ${getSeverityColor(event.severity)}`}
            >
              <Icon className="h-5 w-5 mt-0.5 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-medium">{event.date}</span>
                  <Badge variant="outline" className="text-[10px] uppercase">
                    {event.severity}
                  </Badge>
                </div>
                <p className="text-sm">{event.description}</p>
              </div>
            </div>
          );
        })}
        
        {/* Additional warning items */}
        <div className="pt-3 border-t border-border/30 space-y-2">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <AlertTriangle className="h-3.5 w-3.5 text-destructive" />
            <span>Single source gas dependency (Russia)</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <AlertTriangle className="h-3.5 w-3.5 text-orange-500" />
            <span>Limited storage capacity for winter</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <AlertTriangle className="h-3.5 w-3.5 text-yellow-500" />
            <span>Transit route risks through Ukraine</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
