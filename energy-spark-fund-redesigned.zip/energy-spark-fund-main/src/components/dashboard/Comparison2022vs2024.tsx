import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, Cell } from "recharts";
import { comparison2022vs2024 } from "@/data/moldovaEnergyData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingDown, TrendingUp } from "lucide-react";

const getChangeColor = (change: number) => {
  return change < 0 ? "text-primary" : "text-destructive";
};

const formatValue = (value: number, unit: string) => {
  if (unit === "thousand m³") return `${(value / 1000).toFixed(0)}K`;
  return `${(value / 1000).toFixed(0)}K`;
};

export const Comparison2022vs2024 = () => {
  return (
    <Card className="border-border/30 bg-card/80 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">2022 vs 2024 Comparison</CardTitle>
          <Badge variant="outline" className="text-xs">Crisis Impact</Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[280px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart 
              data={comparison2022vs2024} 
              layout="vertical"
              barCategoryGap="20%"
            >
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} horizontal={false} />
              <XAxis 
                type="number"
                stroke="hsl(var(--muted-foreground))" 
                fontSize={11}
                tickFormatter={(v) => `${(v / 1000000).toFixed(1)}M`}
              />
              <YAxis 
                type="category"
                dataKey="source"
                stroke="hsl(var(--muted-foreground))" 
                fontSize={11}
                width={50}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "8px",
                  fontSize: "12px",
                }}
                formatter={(value: number) => [`${value.toLocaleString()}`, ""]}
              />
              <Legend wrapperStyle={{ fontSize: "11px" }} />
              <Bar dataKey="value2022" name="2022" fill="hsl(0, 0%, 50%)" radius={[0, 4, 4, 0]} />
              <Bar dataKey="value2024" name="2024" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        
        {/* Change indicators */}
        <div className="grid grid-cols-3 gap-3 mt-4">
          {comparison2022vs2024.map((item) => (
            <div key={item.source} className="p-3 rounded-lg bg-background/50 text-center">
              <p className="text-xs text-muted-foreground mb-1">{item.source}</p>
              <div className="flex items-center justify-center gap-1">
                {item.change < 0 ? (
                  <TrendingDown className="h-4 w-4 text-primary" />
                ) : (
                  <TrendingUp className="h-4 w-4 text-destructive" />
                )}
                <span className={`text-lg font-bold ${getChangeColor(item.change)}`}>
                  {item.change > 0 ? "+" : ""}{item.change}%
                </span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
