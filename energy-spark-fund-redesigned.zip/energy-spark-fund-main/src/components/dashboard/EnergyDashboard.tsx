import { InfoCard } from "./InfoCard";
import { MiniChart } from "./MiniChart";
import { energyStats, electricityYearly, energyBalanceByType, naturalGasYearly } from "@/data/energyData";
import { Zap, Flame, Leaf, TrendingUp, Factory, Sun, Wind, Droplets } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";

const electricityChartData = electricityYearly.slice(-6).map((d) => ({
  value: d.production / 1000,
}));

const gasChartData = naturalGasYearly.slice(-6).map((d) => ({
  value: d.consumption / 1000,
}));

const COLORS = [
  "hsl(210, 50%, 55%)",
  "hsl(25, 95%, 53%)",
  "hsl(142, 76%, 50%)",
  "hsl(199, 89%, 48%)",
  "hsl(220, 10%, 40%)",
];

export function EnergyDashboard() {
  return (
    <div className="grid gap-4 md:gap-6">
      {/* Top Stats Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <InfoCard
          title="Electricity Production"
          value="1,124 GWh"
          subtitle="2024 Total"
          icon={Zap}
          trend={{ value: 9.1, isPositive: true }}
          color="primary"
        >
          <MiniChart data={electricityChartData} color="hsl(174, 85%, 45%)" />
        </InfoCard>

        <InfoCard
          title="Natural Gas Import"
          value="1,076M m³"
          subtitle="2024 Total"
          icon={Flame}
          trend={{ value: 24.6, isPositive: true }}
          color="solar"
        >
          <MiniChart data={gasChartData} type="bar" color="hsl(45, 95%, 55%)" />
        </InfoCard>

        <InfoCard
          title="Renewable Share"
          value={`${energyStats.renewableShare}%`}
          subtitle="of total consumption"
          icon={Leaf}
          trend={{ value: 2.3, isPositive: true }}
          color="accent"
        />

        <InfoCard
          title="Import Dependency"
          value={`${energyStats.importDependency}%`}
          subtitle="energy imported"
          icon={TrendingUp}
          color="wind"
        />
      </div>

      {/* Central Dashboard Area */}
      <div className="grid lg:grid-cols-3 gap-4 md:gap-6">
        {/* Energy Mix Pie */}
        <div className="lg:col-span-1 rounded-2xl bg-card/80 backdrop-blur-sm border border-border/50 p-5">
          <h3 className="text-sm font-medium text-muted-foreground mb-4 flex items-center gap-2">
            <Factory className="h-4 w-4 text-primary" />
            Energy Mix 2023
          </h3>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={energyBalanceByType}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {energyBalanceByType.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(220, 25%, 10%)",
                    border: "1px solid hsl(220, 15%, 18%)",
                    borderRadius: "0.75rem",
                  }}
                  itemStyle={{ color: "hsl(210, 20%, 95%)" }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-2 mt-4">
            {energyBalanceByType.slice(0, 4).map((item, index) => (
              <div key={item.name} className="flex items-center gap-2 text-xs">
                <div
                  className="h-2 w-2 rounded-full"
                  style={{ backgroundColor: COLORS[index] }}
                />
                <span className="text-muted-foreground truncate">{item.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Central Map/Infographic Placeholder */}
        <div className="lg:col-span-2 rounded-2xl bg-card/80 backdrop-blur-sm border border-primary/20 p-6 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
          
          {/* Decorative grid */}
          <div className="absolute inset-0 opacity-10">
            <svg className="h-full w-full" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>
          </div>

          <div className="relative z-10">
            <h3 className="text-lg font-semibold mb-2">Moldova Energy Overview</h3>
            <p className="text-sm text-muted-foreground mb-6">Real-time energy production and consumption data</p>

            {/* Key Metrics Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-4 rounded-xl bg-background/50 border border-border/50">
                <Sun className="h-8 w-8 text-energy-solar mx-auto mb-2" />
                <div className="text-2xl font-bold">45%</div>
                <div className="text-xs text-muted-foreground">Solar Potential</div>
              </div>
              <div className="text-center p-4 rounded-xl bg-background/50 border border-border/50">
                <Wind className="h-8 w-8 text-energy-wind mx-auto mb-2" />
                <div className="text-2xl font-bold">25%</div>
                <div className="text-xs text-muted-foreground">Wind Capacity</div>
              </div>
              <div className="text-center p-4 rounded-xl bg-background/50 border border-border/50">
                <Droplets className="h-8 w-8 text-energy-hydro mx-auto mb-2" />
                <div className="text-2xl font-bold">10%</div>
                <div className="text-xs text-muted-foreground">Hydro Power</div>
              </div>
              <div className="text-center p-4 rounded-xl bg-background/50 border border-border/50">
                <Leaf className="h-8 w-8 text-energy-bio mx-auto mb-2" />
                <div className="text-2xl font-bold">20%</div>
                <div className="text-xs text-muted-foreground">Biomass</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
