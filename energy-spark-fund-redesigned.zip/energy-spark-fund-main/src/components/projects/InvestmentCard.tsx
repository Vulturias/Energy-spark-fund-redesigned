import { Link } from "react-router-dom";
import { Project } from "@/data/projectsData";
import { cn } from "@/lib/utils";
import { MapPin, Users, TrendingUp, Sun, Wind, Leaf, Droplets, Lightbulb } from "lucide-react";

interface InvestmentCardProps {
  project: Project;
  className?: string;
  compact?: boolean;
}

const categoryConfig = {
  solar: { color: "#FACC15", icon: Sun, label: "SOLAR" },
  wind: { color: "#0EA5E9", icon: Wind, label: "WIND" },
  biogas: { color: "#22C55E", icon: Leaf, label: "BIO" },
  hydro: { color: "#3B82F6", icon: Droplets, label: "HYDRO" },
  efficiency: { color: "#A855F7", icon: Lightbulb, label: "EFF" },
};

export function InvestmentCard({ project, className, compact = false }: InvestmentCardProps) {
  const fundingPercentage = Math.min(
    (project.fundingRaised / project.fundingGoal) * 100,
    100
  );
  const config = categoryConfig[project.category];
  const CategoryIcon = config.icon;

  const formatAmount = (amount: number) => {
    if (amount >= 1000000) {
      return `€${(amount / 1000000).toFixed(1)}M`;
    }
    return `€${(amount / 1000).toFixed(0)}K`;
  };

  // Gradient based on category
  const gradients = {
    solar: "from-amber-500/20 via-orange-500/10 to-transparent",
    wind: "from-sky-500/20 via-blue-500/10 to-transparent",
    biogas: "from-emerald-500/20 via-green-500/10 to-transparent",
    hydro: "from-cyan-500/20 via-teal-500/10 to-transparent",
    efficiency: "from-purple-500/20 via-violet-500/10 to-transparent",
  };

  if (compact) {
    return (
      <Link to={`/projects/${project.id}`} className="block group">
        <div
          className={cn(
            "glass relative overflow-hidden rounded-md transition-all duration-300 hover:-translate-y-0.5",
            className
          )}
          style={{
            boxShadow: `0 0 30px -10px ${config.color}40`,
          }}
        >
          {/* Gradient background instead of image */}
          <div className={`relative h-16 overflow-hidden bg-gradient-to-br ${gradients[project.category]}`}>
            <div className="absolute inset-0 opacity-30" 
              style={{ 
                backgroundImage: `radial-gradient(circle at 50% 50%, ${config.color}40 0%, transparent 70%)`
              }} 
            />
            
            {/* Category badge */}
            <div 
              className="absolute top-1.5 left-1.5 flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[9px] font-bold backdrop-blur-sm"
              style={{ backgroundColor: `${config.color}20`, color: config.color, boxShadow: `0 0 10px ${config.color}40` }}
            >
              <CategoryIcon className="h-2.5 w-2.5" />
              {config.label}
            </div>

            {/* Days left */}
            <div className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded bg-black/40 backdrop-blur-sm text-[9px] font-semibold font-mono-metric">
              {project.daysLeft}d
            </div>
          </div>

          <div className="relative p-2.5">
            {/* Title */}
            <h3 className="text-xs font-bold line-clamp-1 mb-1 group-hover:text-foreground transition-colors">
              {project.title}
            </h3>

            {/* Location */}
            <div className="flex items-center gap-0.5 text-[9px] text-muted-foreground mb-1.5">
              <MapPin className="h-2.5 w-2.5" />
              {project.location.split(",")[0]}
            </div>

            {/* Progress bar */}
            <div className="h-1 bg-white/5 rounded-full overflow-hidden mb-1.5">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{ 
                  width: `${fundingPercentage}%`,
                  backgroundColor: config.color,
                  boxShadow: `0 0 6px ${config.color}`,
                }}
              />
            </div>

            {/* Stats row */}
            <div className="flex items-center justify-between text-[9px]">
              <div className="flex items-center gap-1">
                <span className="font-bold font-mono-metric" style={{ color: config.color }}>
                  {formatAmount(project.fundingRaised)}
                </span>
                <span className="text-muted-foreground">
                  / {formatAmount(project.fundingGoal)}
                </span>
              </div>
              <div className="flex items-center gap-0.5">
                <Users className="h-2.5 w-2.5 text-muted-foreground" />
                <span className="text-muted-foreground font-mono-metric">{project.backers}</span>
                <span className="font-bold ml-0.5 font-mono-metric" style={{ color: config.color }}>
                  {Math.round(fundingPercentage)}%
                </span>
              </div>
            </div>
          </div>
          
          {/* Hover glow effect */}
          <div 
            className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
            style={{
              background: `radial-gradient(circle at center, ${config.color}15 0%, transparent 70%)`
            }}
          />
        </div>
      </Link>
    );
  }

  return (
    <Link to={`/projects/${project.id}`} className="block group">
      <div
        className={cn(
          "glass-strong relative overflow-hidden rounded-lg transition-all duration-300 hover:-translate-y-1",
          className
        )}
        style={{
          boxShadow: `0 4px 40px -10px ${config.color}50`,
        }}
      >
        {/* Gradient background instead of image */}
        <div className={`relative h-32 overflow-hidden bg-gradient-to-br ${gradients[project.category]}`}>
          <div className="absolute inset-0 opacity-40" 
            style={{ 
              backgroundImage: `radial-gradient(circle at 30% 30%, ${config.color}50 0%, transparent 60%)`
            }} 
          />
          
          {/* Category badge */}
          <div 
            className="absolute top-2 left-2 flex items-center gap-1 px-2 py-1 rounded text-[10px] font-bold backdrop-blur-sm"
            style={{ backgroundColor: `${config.color}25`, color: config.color, boxShadow: `0 0 15px ${config.color}50` }}
          >
            <CategoryIcon className="h-3 w-3" />
            {config.label}
          </div>

          {/* Days left */}
          <div className="absolute top-2 right-2 px-2 py-1 rounded bg-black/50 backdrop-blur-sm text-[10px] font-semibold font-mono-metric">
            {project.daysLeft} days
          </div>
        </div>

        <div className="relative p-4">
          {/* Title */}
          <h3 className="text-sm font-bold line-clamp-1 mb-1 group-hover:text-foreground transition-colors">
            {project.title}
          </h3>

          {/* Location */}
          <div className="flex items-center gap-1 text-[10px] text-muted-foreground mb-3">
            <MapPin className="h-3 w-3" />
            {project.location}
          </div>

          {/* Amount */}
          <div className="flex items-baseline gap-2 mb-2">
            <span className="text-2xl font-black font-mono-metric" style={{ color: config.color }}>
              {formatAmount(project.fundingRaised)}
            </span>
            <span className="text-[10px] text-muted-foreground">
              of {formatAmount(project.fundingGoal)}
            </span>
            <div className="flex items-center gap-0.5 ml-auto">
              <TrendingUp className="h-3.5 w-3.5" style={{ color: config.color }} />
              <span className="text-sm font-bold font-mono-metric" style={{ color: config.color }}>
                {Math.round(fundingPercentage)}%
              </span>
            </div>
          </div>

          {/* Progress bar */}
          <div className="h-1.5 bg-white/5 rounded-full overflow-hidden mb-2">
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{ 
                width: `${fundingPercentage}%`,
                backgroundColor: config.color,
                boxShadow: `0 0 12px ${config.color}80`,
              }}
            />
          </div>

          {/* Stats */}
          <div className="flex items-center justify-between text-[10px] text-muted-foreground">
            <div className="flex items-center gap-1">
              <Users className="h-3 w-3" />
              <span className="font-medium font-mono-metric">{project.backers.toLocaleString()} backers</span>
            </div>
            <span className="font-mono-metric">Goal: {formatAmount(project.fundingGoal)}</span>
          </div>
        </div>
        
        {/* Hover glow effect */}
        <div 
          className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
          style={{
            background: `radial-gradient(circle at center, ${config.color}20 0%, transparent 70%)`
          }}
        />
      </div>
    </Link>
  );
}