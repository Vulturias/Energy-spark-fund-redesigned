import { Link } from "react-router-dom";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, Users, Clock } from "lucide-react";
import { Project } from "@/data/projectsData";
import { cn } from "@/lib/utils";

interface ProjectCardProps {
  project: Project;
  className?: string;
}

const categoryColors = {
  solar: "bg-energy-solar/20 text-energy-solar border-energy-solar/30",
  wind: "bg-energy-wind/20 text-energy-wind border-energy-wind/30",
  biogas: "bg-energy-bio/20 text-energy-bio border-energy-bio/30",
  hydro: "bg-energy-hydro/20 text-energy-hydro border-energy-hydro/30",
  efficiency: "bg-primary/20 text-primary border-primary/30",
};

export function ProjectCard({ project, className }: ProjectCardProps) {
  const fundingPercentage = Math.min(
    (project.fundingRaised / project.fundingGoal) * 100,
    100
  );

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "EUR",
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <Link to={`/projects/${project.id}`}>
      <Card
        className={cn(
          "group overflow-hidden transition-all duration-300 hover:shadow-lg hover:-translate-y-1 border-border/50",
          className
        )}
      >
        <div className="relative aspect-video overflow-hidden">
          <img
            src={project.image}
            alt={project.title}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute top-3 left-3">
            <Badge
              variant="outline"
              className={cn(
                "backdrop-blur-sm border capitalize",
                categoryColors[project.category]
              )}
            >
              {project.category}
            </Badge>
          </div>
          {project.featured && (
            <div className="absolute top-3 right-3">
              <Badge className="bg-primary text-primary-foreground">
                Featured
              </Badge>
            </div>
          )}
        </div>

        <CardContent className="p-5">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
            <MapPin className="h-3.5 w-3.5" />
            <span>{project.location}</span>
          </div>

          <h3 className="font-semibold text-lg mb-2 line-clamp-1 group-hover:text-primary transition-colors">
            {project.title}
          </h3>

          <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
            {project.shortDescription}
          </p>

          <div className="space-y-3">
            <Progress value={fundingPercentage} className="h-2" />

            <div className="flex items-center justify-between text-sm">
              <div>
                <span className="font-semibold text-foreground">
                  {formatCurrency(project.fundingRaised)}
                </span>
                <span className="text-muted-foreground">
                  {" "}
                  / {formatCurrency(project.fundingGoal)}
                </span>
              </div>
              <span className="font-medium text-primary">
                {Math.round(fundingPercentage)}%
              </span>
            </div>

            <div className="flex items-center justify-between text-sm text-muted-foreground pt-2 border-t border-border">
              <div className="flex items-center gap-1.5">
                <Users className="h-3.5 w-3.5" />
                <span>{project.backers.toLocaleString()} backers</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5" />
                <span>{project.daysLeft} days left</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
